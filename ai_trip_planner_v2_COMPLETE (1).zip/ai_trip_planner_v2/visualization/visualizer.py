"""
Visualization Module
Handles graph visualization and analytics charts
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.figure import Figure
import networkx as nx
from typing import List, Dict, Tuple, Optional
import io
from PIL import Image


class GraphVisualizer:
    """Visualize city network graphs"""
    
    def __init__(self, figsize: Tuple[int, int] = (12, 8)):
        self.figsize = figsize
    
    def visualize_graph(self, graph: nx.Graph, highlighted_path: List[str] = None) -> Image.Image:
        """Visualize the city network graph"""
        fig, ax = plt.subplots(figsize=self.figsize, facecolor='#1a1a1a')
        ax.set_facecolor('#1a1a1a')
        
        # Use spring layout for better visualization
        pos = nx.spring_layout(graph, k=2, iterations=50, seed=42)
        
        # Draw all edges
        nx.draw_networkx_edges(graph, pos, ax=ax, edge_color='#444444', width=1.5, alpha=0.6)
        
        # Draw all nodes
        node_colors = []
        for node in graph.nodes():
            if highlighted_path and node in highlighted_path:
                node_colors.append('#00ff00')
            else:
                node_colors.append('#0088ff')
        
        nx.draw_networkx_nodes(graph, pos, ax=ax, node_color=node_colors, 
                              node_size=800, alpha=0.9)
        
        # Draw labels
        nx.draw_networkx_labels(graph, pos, ax=ax, font_size=8, 
                               font_color='white', font_weight='bold')
        
        # Highlight path if provided
        if highlighted_path and len(highlighted_path) > 1:
            path_edges = [(highlighted_path[i], highlighted_path[i+1]) 
                         for i in range(len(highlighted_path)-1)]
            nx.draw_networkx_edges(graph, pos, edgelist=path_edges, ax=ax, 
                                  edge_color='#ff0000', width=3)
        
        ax.set_title('City Network Graph', color='white', fontsize=16, fontweight='bold')
        ax.axis('off')
        
        return self._fig_to_image(fig)
    
    def visualize_route_comparison(self, routes: Dict[str, Dict]) -> Image.Image:
        """Visualize comparison of different routes"""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10), facecolor='#1a1a1a')
        fig.suptitle('Route Comparison Analysis', color='white', fontsize=16, fontweight='bold')
        
        algorithms = list(routes.keys())
        costs = [routes[algo].get('cost', 0) for algo in algorithms]
        times = [routes[algo].get('execution_time', 0) for algo in algorithms]
        nodes = [len(routes[algo].get('explored_nodes', [])) for algo in algorithms]
        
        # Cost comparison
        ax = axes[0, 0]
        ax.set_facecolor('#2a2a2a')
        ax.bar(algorithms, costs, color='#00ff00', alpha=0.7)
        ax.set_ylabel('Cost (₹)', color='white')
        ax.set_title('Route Cost', color='white')
        ax.tick_params(colors='white')
        
        # Execution time
        ax = axes[0, 1]
        ax.set_facecolor('#2a2a2a')
        ax.bar(algorithms, times, color='#ff6600', alpha=0.7)
        ax.set_ylabel('Time (seconds)', color='white')
        ax.set_title('Execution Time', color='white')
        ax.tick_params(colors='white')
        
        # Explored nodes
        ax = axes[1, 0]
        ax.set_facecolor('#2a2a2a')
        ax.bar(algorithms, nodes, color='#0088ff', alpha=0.7)
        ax.set_ylabel('Nodes Explored', color='white')
        ax.set_title('Nodes Explored', color='white')
        ax.tick_params(colors='white')
        
        # Summary table
        ax = axes[1, 1]
        ax.axis('off')
        
        return self._fig_to_image(fig)
    
    def visualize_budget_breakdown(self, budget_data: Dict[str, float]) -> Image.Image:
        """Visualize budget breakdown"""
        fig, ax = plt.subplots(figsize=(10, 8), facecolor='#1a1a1a')
        ax.set_facecolor('#1a1a1a')
        
        categories = list(budget_data.keys())
        amounts = list(budget_data.values())
        colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#ffa07a', '#98d8c8', '#f7dc6f']
        
        wedges, texts, autotexts = ax.pie(amounts, labels=categories, autopct='%1.1f%%',
                                          colors=colors[:len(categories)], startangle=90)
        
        for text in texts:
            text.set_color('white')
            text.set_fontsize(10)
        
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
        
        ax.set_title('Budget Breakdown', color='white', fontsize=14, fontweight='bold')
        
        return self._fig_to_image(fig)
    
    def visualize_daily_schedule(self, schedule: List[Dict]) -> Image.Image:
        """Visualize daily schedule timeline"""
        fig, ax = plt.subplots(figsize=(14, 6), facecolor='#1a1a1a')
        ax.set_facecolor('#1a1a1a')
        
        days = [f"Day {i+1}" for i in range(len(schedule))]
        activities = [len(day.get('activities', [])) for day in schedule]
        
        bars = ax.bar(days, activities, color='#0088ff', alpha=0.7, edgecolor='#00ff00', linewidth=2)
        
        ax.set_ylabel('Number of Activities', color='white', fontsize=12)
        ax.set_title('Daily Activity Schedule', color='white', fontsize=14, fontweight='bold')
        ax.tick_params(colors='white')
        
        # Add value labels on bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{int(height)}',
                   ha='center', va='bottom', color='white', fontweight='bold')
        
        return self._fig_to_image(fig)
    
    def visualize_travel_statistics(self, stats: Dict) -> Image.Image:
        """Visualize travel statistics"""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10), facecolor='#1a1a1a')
        fig.suptitle('Travel Statistics', color='white', fontsize=16, fontweight='bold')
        
        # Total trips
        ax = axes[0, 0]
        ax.set_facecolor('#2a2a2a')
        ax.text(0.5, 0.5, f"{stats.get('total_trips', 0)}", 
               ha='center', va='center', fontsize=48, color='#00ff00', fontweight='bold',
               transform=ax.transAxes)
        ax.text(0.5, 0.1, 'Total Trips', ha='center', va='center', fontsize=12, 
               color='white', transform=ax.transAxes)
        ax.axis('off')
        
        # Total distance
        ax = axes[0, 1]
        ax.set_facecolor('#2a2a2a')
        ax.text(0.5, 0.5, f"{stats.get('total_distance', 0):.0f} km", 
               ha='center', va='center', fontsize=40, color='#ff6600', fontweight='bold',
               transform=ax.transAxes)
        ax.text(0.5, 0.1, 'Total Distance', ha='center', va='center', fontsize=12, 
               color='white', transform=ax.transAxes)
        ax.axis('off')
        
        # Total spent
        ax = axes[1, 0]
        ax.set_facecolor('#2a2a2a')
        ax.text(0.5, 0.5, f"₹{stats.get('total_spent', 0):,.0f}", 
               ha='center', va='center', fontsize=40, color='#00ff88', fontweight='bold',
               transform=ax.transAxes)
        ax.text(0.5, 0.1, 'Total Spent', ha='center', va='center', fontsize=12, 
               color='white', transform=ax.transAxes)
        ax.axis('off')
        
        # Average duration
        ax = axes[1, 1]
        ax.set_facecolor('#2a2a2a')
        ax.text(0.5, 0.5, f"{stats.get('avg_duration', 0):.1f} days", 
               ha='center', va='center', fontsize=40, color='#0088ff', fontweight='bold',
               transform=ax.transAxes)
        ax.text(0.5, 0.1, 'Avg Duration', ha='center', va='center', fontsize=12, 
               color='white', transform=ax.transAxes)
        ax.axis('off')
        
        return self._fig_to_image(fig)
    
    @staticmethod
    def _fig_to_image(fig: Figure) -> Image.Image:
        """Convert matplotlib figure to PIL Image"""
        buf = io.BytesIO()
        fig.savefig(buf, format='png', facecolor='#1a1a1a', edgecolor='none', bbox_inches='tight')
        buf.seek(0)
        image = Image.open(buf)
        plt.close(fig)
        return image
