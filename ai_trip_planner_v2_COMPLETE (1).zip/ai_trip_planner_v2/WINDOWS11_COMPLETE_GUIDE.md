# Windows 11 Complete Setup & Execution Guide
## AI-Powered Smart Trip Planner V2

---

## 🎯 OVERVIEW

This guide is **100% specific to Windows 11**. Follow each step exactly as shown.

**Total Time: 15-20 minutes**

---

## ✅ PHASE 1: VERIFY PYTHON 3.14 INSTALLATION (2 minutes)

### Step 1.1: Open Command Prompt

**Method 1 (Fastest):**
1. Press `Win + R` (Windows key + R)
2. Type: `cmd`
3. Press `Enter`

**Command Prompt opens:**
```
Microsoft Windows [Version 10.0.22631]
(c) Microsoft Corporation. All rights reserved.

C:\Users\YourUsername>
```

**Method 2 (Alternative):**
1. Click Windows Start button (bottom left)
2. Type: `command prompt`
3. Click "Command Prompt" in results

**Method 3 (PowerShell):**
1. Right-click on Desktop
2. Select "Open in Terminal"

---

### Step 1.2: Check Python Version

**Type this command:**
```bash
python --version
```

**Press Enter**

**Expected Output:**
```
Python 3.14.0
```

**If you see this, you're good! ✅**

---

### Step 1.3: If Python Not Found

**If you get:**
```
'python' is not recognized as an internal or external command
```

**Then:**
1. Download Python 3.14 from https://www.python.org/downloads/
2. Run the installer
3. **IMPORTANT:** Check the box "Add Python to PATH"
4. Click "Install Now"
5. Wait for installation
6. Restart Command Prompt
7. Try `python --version` again

---

## ✅ PHASE 2: EXTRACT THE ZIP FILE (2 minutes)

### Step 2.1: Find the ZIP File

**You should have:**
```
📁 Downloads
├── 📦 ai_trip_planner_v2_complete.zip
```

**Or check:**
- Desktop
- Documents
- Downloads folder

**If you can't find it:**
1. Click File Explorer (folder icon in taskbar)
2. Look in Downloads folder
3. Search for "ai_trip_planner"

---

### Step 2.2: Right-Click the ZIP File

**Screenshot:**
```
File Explorer Window:
┌─────────────────────────────────────────────────────────┐
│ File  Edit  View  Tools  Help                           │
├─────────────────────────────────────────────────────────┤
│ 📁 This PC > Downloads                                  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📦 ai_trip_planner_v2_complete.zip                    │
│   ↑ Right-click here                                    │
│                                                         │
│  Context Menu:                                          │
│  ├── Open                                               │
│  ├── Open with                                          │
│  ├── Send to                                            │
│  ├── Cut                                                │
│  ├── Copy                                               │
│  ├── Delete                                             │
│  ├── Rename                                             │
│  ├── Properties                                         │
│  └── Extract All...  ← CLICK THIS                      │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Right-click on the ZIP file and select "Extract All..."**

---

### Step 2.3: Extract Dialog Appears

**Window:**
```
┌─────────────────────────────────────────────────────────┐
│ Extract Compressed (Zipped) Folder                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Select a destination and press Extract to unzip the    │
│ file(s).                                               │
│                                                         │
│ Destination: C:\Users\YourUsername\Downloads          │
│              [Browse...]                               │
│                                                         │
│ ☑ Show extracted files when complete                   │
│                                                         │
│ [Cancel]  [Extract]                                    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**The default location is fine!**

---

### Step 2.4: Click "Extract"

**Extraction starts:**
```
Extracting files...
████████████████████████░░░░░░░░░░ 65%
```

**Wait for completion...**

---

### Step 2.5: New Folder Appears

**After extraction:**
```
📁 Downloads
├── 📦 ai_trip_planner_v2_complete.zip  (original)
└── 📁 ai_trip_planner_v2/               (NEW!) ← Double-click to open
    ├── main.py
    ├── requirements.txt
    ├── engine/
    ├── gui/
    ├── data/
    ├── README.md
    ├── QUICK_START.md
    └── [other files]
```

✅ **Extraction complete!**

---

## ✅ PHASE 3: OPEN COMMAND PROMPT IN PROJECT FOLDER (1 minute)

### Step 3.1: Open the Extracted Folder

**Double-click:**
```
📁 ai_trip_planner_v2
```

**Folder opens:**
```
File Explorer Window:
┌─────────────────────────────────────────────────────────┐
│ File  Edit  View  Tools  Help                           │
├─────────────────────────────────────────────────────────┤
│ 📁 This PC > Downloads > ai_trip_planner_v2             │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📄 main.py                                             │
│  📄 requirements.txt                                    │
│  📁 engine/                                             │
│  📁 gui/                                                │
│  📁 data/                                               │
│  📄 README.md                                           │
│  📄 QUICK_START.md                                      │
│  [... more files ...]                                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

### Step 3.2: Open Command Prompt Here

**Method 1 (Easiest in Windows 11):**
1. Click on the address bar (top)
2. Type: `cmd`
3. Press `Enter`

**Command Prompt opens in this folder:**
```
C:\Users\YourUsername\Downloads\ai_trip_planner_v2>
```

**Method 2 (Alternative):**
1. Right-click in empty space (not on files)
2. Select "Open in Terminal"

**Method 3 (Manual):**
1. Open Command Prompt (Win + R, type cmd)
2. Type: `cd Downloads\ai_trip_planner_v2`
3. Press Enter

---

### Step 3.3: Verify You're in Correct Folder

**Type this command:**
```bash
dir
```

**Press Enter**

**You should see:**
```
Directory of C:\Users\YourUsername\Downloads\ai_trip_planner_v2

2026-06-07  14:38    <DIR>          .
2026-06-07  14:38    <DIR>          ..
2026-06-07  14:38    <DIR>          engine
2026-06-07  14:38    <DIR>          gui
2026-06-07  14:38    <DIR>          data
2026-06-07  14:38             2,048 main.py
2026-06-07  14:38               156 requirements.txt
2026-06-07  14:38             5,120 README.md
```

✅ **You're in the right folder!**

---

## ✅ PHASE 4: INSTALL DEPENDENCIES (3-5 minutes)

### Step 4.1: Install Python Packages

**Type this command:**
```bash
pip install -r requirements.txt
```

**Press Enter**

**Installation starts:**
```
Collecting customtkinter
  Downloading customtkinter-5.2.0-py3-none-win_amd64.whl (1.2 MB)
     |████████████████████████████████| 1.2 MB 2.5 MB/s

Collecting networkx
  Downloading networkx-3.2.1-py3-none-any.whl (2.1 MB)
     |████████████████████████████████| 2.1 MB 3.1 MB/s

Collecting matplotlib
  Downloading matplotlib-3.8.2-py3-none-any.whl (7.5 MB)
     |████████████████████████████████| 7.5 MB 2.8 MB/s

Installing collected packages: customtkinter, networkx, matplotlib
Successfully installed customtkinter-5.2.0
Successfully installed networkx-3.2.1
Successfully installed matplotlib-3.8.2
```

**Wait for completion...**

---

### Step 4.2: Verify Installation

**Type this command:**
```bash
pip list
```

**Press Enter**

**You should see:**
```
Package            Version
------------------ -------
customtkinter      5.2.0
networkx           3.2.1
matplotlib         3.8.2
...
```

✅ **Dependencies installed!**

---

## ✅ PHASE 5: CREATE DATA DIRECTORY (30 seconds)

### Step 5.1: Create Folder

**Type this command:**
```bash
mkdir data\trips
```

**Press Enter**

**No output = success!**

---

### Step 5.2: Verify Folder Created

**Type this command:**
```bash
dir data
```

**Press Enter**

**You should see:**
```
Directory of C:\Users\YourUsername\Downloads\ai_trip_planner_v2\data

2026-06-07  15:00    <DIR>          .
2026-06-07  15:00    <DIR>          ..
2026-06-07  15:00    <DIR>          trips
```

✅ **Data directory created!**

---

## ✅ PHASE 6: RUN THE APPLICATION (30 seconds)

### Step 6.1: Start the Application

**Type this command:**
```bash
python main.py
```

**Press Enter**

**Terminal shows:**
```
Starting AI-Powered Smart Trip Planner...
GUI initialized successfully
Waiting for user input...
```

---

### Step 6.2: Application Window Opens

**A new window appears:**
```
┌─────────────────────────────────────────────────────────┐
│ AI-Powered Smart Trip Planner                  _ □ X  │
├─────────────────────────────────────────────────────────┤
│ [Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics] │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  🏠 DASHBOARD                                          │
│  ═══════════════════════════════════════════════════   │
│                                                         │
│  📊 QUICK STATS                                        │
│  ┌─────────────┬─────────────┬─────────────┐          │
│  │ 📊 Trips: 0 │ 📍 Cities: 0 │ 💰 Spent: ₹0 │         │
│  └─────────────┴─────────────┴─────────────┘          │
│                                                         │
│  [✈️ New Trip] [📂 Load] [📊 Compare] [⚙️ Settings]   │
│                                                         │
│  📅 UPCOMING TRIPS                                     │
│  (No trips yet)                                        │
│                                                         │
│  💡 AI RECOMMENDATIONS                                 │
│  • Great weather expected in Bangalore next week       │
│  • Flight prices dropping for Mumbai-Delhi route       │
│  • New luxury hotels opened in Hyderabad               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

✅ **Application is running!**

---

## ✅ PHASE 7: CREATE YOUR FIRST TRIP (5-10 minutes)

### Step 7.1: Click "New Trip" Tab

**In the application window:**
```
[Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics]
             ↑ CLICK HERE
```

**Form appears:**
```
┌─────────────────────────────────────────────────────────┐
│ ✈️ Plan Your Perfect Trip                              │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ From City:        [Mumbai          ▼]                 │
│ To City:          [Delhi           ▼]                 │
│ Start Date:       [2026-06-15     ]                   │
│ Duration:         [5              ]                   │
│ Budget:           [75000          ]                   │
│ Transport Mode:   [flight         ▼]                 │
│ Comfort Level:    [comfort        ▼]                 │
│ Risk Tolerance:   [0.5            ]                   │
│ Interests:        [sightseeing,food,culture]          │
│                                                         │
│ [🚀 Generate Itinerary]                               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

### Step 7.2: Fill in Each Field

**1. From City:**
- Click the dropdown
- Select "Mumbai"

**2. To City:**
- Click the dropdown
- Select "Delhi"

**3. Start Date:**
- Click the field
- Clear it
- Type: `2026-06-15`

**4. Duration:**
- Click the field
- Clear it
- Type: `5`

**5. Budget:**
- Click the field
- Clear it
- Type: `75000`

**6. Transport Mode:**
- Click the dropdown
- Select "flight"

**7. Comfort Level:**
- Click the dropdown
- Select "comfort"

**8. Risk Tolerance:**
- Click the field
- Clear it
- Type: `0.5`

**9. Interests:**
- Click the field
- Clear it
- Type: `sightseeing,food,culture`

**Completed Form:**
```
From City:        Mumbai
To City:          Delhi
Start Date:       2026-06-15
Duration:         5
Budget:           75000
Transport Mode:   flight
Comfort Level:    comfort
Risk Tolerance:   0.5
Interests:        sightseeing,food,culture
```

---

### Step 7.3: Generate Itinerary

**Click the button:**
```
[🚀 Generate Itinerary]
```

**Wait 2-3 seconds...**

**Success message appears:**
```
┌─────────────────────────────────────────────────────────┐
│ ✅ Itinerary generated successfully!                   │
│                                                         │
│ [OK]                                                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Click OK**

---

### Step 7.4: View Trip Details

**Automatically shows "📋 Trip Details" tab:**
```
┌─────────────────────────────────────────────────────────┐
│ 📋 Trip Details                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ ════════════════════════════════════════════════════  │
│ ✈️ TRIP ITINERARY: Mumbai → Delhi                    │
│ ════════════════════════════════════════════════════  │
│                                                         │
│ 📅 TRIP OVERVIEW                                      │
│ ─────────────────────────────────────────────────────  │
│ Trip ID: trip_20260607_143825                        │
│ Duration: 5 days (2026-06-15 to 2026-06-19)         │
│ Budget: ₹75,000                                      │
│ Total Cost: ₹72,000                                  │
│ Distance: 1400 km                                    │
│ Transport: FLIGHT                                    │
│ Comfort Level: COMFORT                               │
│                                                         │
│ ════════════════════════════════════════════════════  │
│ 📋 DAY-BY-DAY ITINERARY                              │
│ ════════════════════════════════════════════════════  │
│                                                         │
│ 📍 DAY 1 - 2026-06-15 (Mumbai)                       │
│ ─────────────────────────────────────────────────────  │
│ Activities:                                           │
│ • Breakfast at hotel                                 │
│ • Visit Gateway of India                            │
│ • Lunch at local restaurant                         │
│ • Explore Marine Drive                              │
│ • Dinner at Taj Mahal Palace                        │
│                                                         │
│ 🏨 Hotels:                                            │
│ • Taj Mahal Palace - ₹12,000/night (Rating: 4.8/5)  │
│ • Oberoi Mumbai - ₹10,500/night (Rating: 4.7/5)     │
│ • Trident Mumbai - ₹9,500/night (Rating: 4.6/5)     │
│                                                         │
│ 🎫 Attractions:                                       │
│ • Gateway of India - Historic monument (Rating: 4.9) │
│ • Marine Drive - Scenic coastal road (Rating: 4.8)   │
│ • Taj Mahal Palace - Luxury hotel tour (Rating: 4.7) │
│                                                         │
│ 🍽️ Meals:                                             │
│ • Breakfast: Vada Pav                                │
│ • Lunch: Pav Bhaji                                   │
│ • Dinner: Seafood specialties                        │
│                                                         │
│ 💰 Estimated Daily Budget: ₹15,000                   │
│                                                         │
│ [... scroll down to see Days 2-5 ...]                │
│                                                         │
│ ════════════════════════════════════════════════════  │
│ 💡 AI RECOMMENDATIONS                                 │
│ ════════════════════════════════════════════════════  │
│ • ✈️ Flight recommended for faster travel             │
│ • 🌤️ Check weather forecast for monsoon              │
│ • 🎫 Book attractions in advance                     │
│ • 🍽️ Try local street food for authentic experience  │
│ • 💵 Use public transport and eat at local restaurants│
│ • 🏨 Confirm hotel bookings 24 hours before arrival   │
│                                                         │
│ [💾 Save Trip] [📄 Export PDF] [📤 Share]           │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

### Step 7.5: Scroll to See More

**Use the scrollbar on the right to see:**
- Days 2, 3, 4, 5 itineraries
- More attractions
- More recommendations

---

## ✅ PHASE 8: SAVE YOUR TRIP (1 minute)

### Step 8.1: Click "Save Trip"

**In Trip Details tab:**
```
[💾 Save Trip] [📄 Export PDF] [📤 Share]
 ↑ CLICK HERE
```

**Success message:**
```
┌─────────────────────────────────────────────────────────┐
│ ✅ Trip saved successfully!                            │
│ Trip ID: trip_20260607_143825                          │
│                                                         │
│ [OK]                                                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Click OK**

---

## ✅ PHASE 9: VIEW SAVED TRIPS (1 minute)

### Step 9.1: Click "Saved Trips" Tab

**In the application:**
```
[Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics]
                                        ↑ CLICK HERE
```

**You see:**
```
💾 SAVED TRIPS
═══════════════════════════════════════════════════

📍 Mumbai → Delhi
   📅 2026-06-15 to 2026-06-19 (5 days)
   💰 ₹72,000 / ₹75,000
   ✈️ FLIGHT
   ID: trip_20260607_143825
────────────────────────────────────────────────────

(You can add more trips here)
```

✅ **Trip saved!**

---

## ✅ PHASE 10: VIEW ANALYTICS (1 minute)

### Step 10.1: Click "Analytics" Tab

**In the application:**
```
[Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics]
                                                    ↑ CLICK HERE
```

**You see:**
```
📊 TRAVEL ANALYTICS
═══════════════════════════════════════════════════

🌍 TRAVEL STATISTICS
─────────────────────────────────────────────────────

📊 Total Trips: 1
📍 Total Distance: 1400 km
💰 Total Spent: ₹72,000
⏱️ Average Trip Duration: 5.0 days

🏙️ Favorite Cities: Delhi, Mumbai
✈️ Favorite Transport: flight
🌍 Most Visited: Delhi
🌱 Carbon Footprint: 210 kg CO2
```

✅ **Analytics displayed!**

---

## 🎉 COMPLETE! YOU'RE DONE!

**Congratulations!** You have successfully:

✅ Verified Python 3.14
✅ Extracted the ZIP file
✅ Opened Command Prompt in project folder
✅ Installed all dependencies
✅ Created data directory
✅ Ran the application
✅ Created your first trip (Mumbai → Delhi)
✅ Generated complete itinerary
✅ Saved the trip
✅ Viewed saved trips
✅ Checked analytics

---

## 🔄 CREATE MORE TRIPS

### Trip 2: Budget Beach Adventure
```
From City:        Bangalore
To City:          Goa
Start Date:       2026-07-01
Duration:         3
Budget:           40000
Transport Mode:   bus
Comfort Level:    budget
Risk Tolerance:   0.7
Interests:        beaches,food,nightlife
```

### Trip 3: Luxury City Tour
```
From City:        Delhi
To City:          Jaipur
Start Date:       2026-08-01
Duration:         4
Budget:           150000
Transport Mode:   flight
Comfort Level:    luxury
Risk Tolerance:   0.3
Interests:        culture,shopping,heritage
```

---

## 🆘 WINDOWS 11 TROUBLESHOOTING

### Problem: "Python is not recognized"

**Solution:**
1. Download Python 3.14 from https://www.python.org/downloads/
2. Run installer
3. **CHECK:** "Add Python to PATH"
4. Click "Install Now"
5. Restart Command Prompt
6. Try again

### Problem: "ModuleNotFoundError: No module named 'customtkinter'"

**Solution:**
```bash
pip install customtkinter
```

Then run again:
```bash
python main.py
```

### Problem: Application won't start

**Solution:**
1. Make sure you're in the right folder:
   ```bash
   dir
   ```
   Should show: `main.py`, `requirements.txt`, `engine/`, `gui/`, etc.

2. Try running with full path:
   ```bash
   python C:\Users\YourUsername\Downloads\ai_trip_planner_v2\main.py
   ```

### Problem: GUI appears blank

**Solution:**
1. Close the application
2. Delete cache folder:
   ```bash
   rmdir /s __pycache__
   ```
3. Run again:
   ```bash
   python main.py
   ```

### Problem: "Cannot find data directory"

**Solution:**
```bash
mkdir data\trips
python main.py
```

### Problem: ZIP file won't extract

**Solution:**
1. Try right-click → "Extract All..." again
2. Or download 7-Zip: https://www.7-zip.org/
3. Right-click ZIP → 7-Zip → Extract Here

---

## 📋 QUICK REFERENCE COMMANDS

**Navigate to folder:**
```bash
cd Downloads\ai_trip_planner_v2
```

**Check Python:**
```bash
python --version
```

**Install dependencies:**
```bash
pip install -r requirements.txt
```

**Create data folder:**
```bash
mkdir data\trips
```

**Run application:**
```bash
python main.py
```

**List files:**
```bash
dir
```

**Delete cache:**
```bash
rmdir /s __pycache__
```

---

## ✅ VERIFICATION CHECKLIST

After completing all steps:
- [ ] Python 3.14 installed and verified
- [ ] ZIP file extracted successfully
- [ ] Command Prompt opened in project folder
- [ ] Dependencies installed (customtkinter, networkx, matplotlib)
- [ ] Data directory created
- [ ] Application starts without errors
- [ ] GUI window appears with 5 tabs
- [ ] Can fill and submit trip form
- [ ] Itinerary generates successfully
- [ ] Trip details display correctly
- [ ] Trip saves successfully
- [ ] Saved trips appear in list
- [ ] Analytics shows statistics

---

## 🎮 NEXT STEPS

1. ✅ Create your first trip (done!)
2. ✅ Create 2-3 more trips with different preferences
3. ✅ Compare trips in "Saved Trips" tab
4. ✅ Explore all features
5. ✅ Customize the code for your needs

---

## 📚 ADDITIONAL RESOURCES

- **README.md** - Feature overview
- **QUICK_START.md** - 5-minute setup
- **SETUP_GUIDE.md** - Detailed installation
- **DOCUMENTATION.md** - Technical details + Viva Q&A

---

## 🌍 AVAILABLE CITIES

You can plan trips between these 10 Indian cities:
- Mumbai
- Delhi
- Bangalore
- Hyderabad
- Chennai
- Pune
- Jaipur
- Kochi
- Kolkata
- Ahmedabad

---

## 💡 PRO TIPS FOR WINDOWS 11

1. **Pin Command Prompt to Taskbar:**
   - Right-click Command Prompt
   - Select "Pin to taskbar"
   - Quick access next time!

2. **Create Shortcut to Project:**
   - Right-click `ai_trip_planner_v2` folder
   - Select "Create shortcut"
   - Put on Desktop for quick access

3. **Use Windows Terminal (Modern):**
   - Instead of Command Prompt
   - Right-click folder → "Open in Terminal"
   - More modern interface

4. **Keep Command Prompt Window Open:**
   - Don't close it while app is running
   - Shows logs and errors
   - Close when done

---

**Happy Trip Planning!** ✈️🌍

**Questions?** Check the documentation files or re-read the relevant section above.

**Enjoy your AI-Powered Smart Trip Planner!** 🎉
