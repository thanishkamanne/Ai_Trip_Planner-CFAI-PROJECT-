"""
GUI module - User interface components
"""

from .enhanced_dashboard import EnhancedDashboard, TripPlannerWindow

__all__ = ["EnhancedDashboard", "TripPlannerWindow"]
