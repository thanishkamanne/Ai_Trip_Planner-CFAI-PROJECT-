"""
Enhanced Dashboard GUI
Modern, professional dashboard for trip planning
"""

import customtkinter as ctk
from tkinter import ttk, messagebox
from typing import Callable, Optional, List, Dict
from datetime import datetime, timedelta
from engine.models import (
    TripItinerary, TransportMode, ComfortLevel, TravelStatistics
)


class EnhancedDashboard(ctk.CTkFrame):
    """Enhanced dashboard with modern design"""
    
    def __init__(self, parent, on_new_trip: Callable, on_load_trip: Callable,
                 on_view_trip: Callable, **kwargs):
        super().__init__(parent, **kwargs)
        self.on_new_trip = on_new_trip
        self.on_load_trip = on_load_trip
        self.on_view_trip = on_view_trip
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup dashboard UI"""
        # Configure grid
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Main container
        main_container = ctk.CTkScrollableFrame(self, fg_color="transparent")
        main_container.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        main_container.grid_columnconfigure(0, weight=1)
        
        # Header section
        self._create_header(main_container)
        
        # Quick stats section
        self._create_stats_section(main_container)
        
        # Quick actions section
        self._create_quick_actions(main_container)
        
        # Upcoming trips section
        self._create_upcoming_trips(main_container)
        
        # AI recommendations section
        self._create_recommendations(main_container)
    
    def _create_header(self, parent):
        """Create dashboard header"""
        header_frame = ctk.CTkFrame(parent, fg_color="transparent")
        header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 30))
        header_frame.grid_columnconfigure(0, weight=1)
        
        # Title
        title_label = ctk.CTkLabel(
            header_frame,
            text="🌍 Smart Trip Planner Dashboard",
            font=("Helvetica", 28, "bold"),
            text_color="#00d9ff"
        )
        title_label.grid(row=0, column=0, sticky="w")
        
        # Subtitle
        subtitle_label = ctk.CTkLabel(
            header_frame,
            text="Plan your perfect journey with AI-powered recommendations",
            font=("Helvetica", 12),
            text_color="#888888"
        )
        subtitle_label.grid(row=1, column=0, sticky="w", pady=(5, 0))
    
    def _create_stats_section(self, parent):
        """Create statistics section"""
        stats_frame = ctk.CTkFrame(parent, fg_color="#1a1a1a", corner_radius=15)
        stats_frame.grid(row=1, column=0, sticky="ew", pady=(0, 20))
        stats_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)
        
        # Sample stats
        stats = [
            ("📊 Total Trips", "5", "#00d9ff"),
            ("📍 Cities Visited", "12", "#00a8cc"),
            ("💰 Total Spent", "₹2,50,000", "#0081b4"),
            ("✈️ Avg Duration", "4.2 days", "#005a8d")
        ]
        
        for idx, (label, value, color) in enumerate(stats):
            stat_card = self._create_stat_card(stats_frame, label, value, color)
            stat_card.grid(row=0, column=idx, padx=10, pady=15, sticky="ew")
    
    def _create_stat_card(self, parent, label: str, value: str, color: str) -> ctk.CTkFrame:
        """Create a stat card"""
        card = ctk.CTkFrame(parent, fg_color="#2a2a2a", corner_radius=10)
        card.grid_columnconfigure(0, weight=1)
        
        label_widget = ctk.CTkLabel(
            card,
            text=label,
            font=("Helvetica", 11),
            text_color="#888888"
        )
        label_widget.grid(row=0, column=0, padx=15, pady=(10, 5))
        
        value_widget = ctk.CTkLabel(
            card,
            text=value,
            font=("Helvetica", 18, "bold"),
            text_color=color
        )
        value_widget.grid(row=1, column=0, padx=15, pady=(5, 10))
        
        return card
    
    def _create_quick_actions(self, parent):
        """Create quick action buttons"""
        actions_frame = ctk.CTkFrame(parent, fg_color="transparent")
        actions_frame.grid(row=2, column=0, sticky="ew", pady=(0, 20))
        actions_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)
        
        # New Trip button
        new_trip_btn = ctk.CTkButton(
            actions_frame,
            text="✈️ New Trip",
            font=("Helvetica", 13, "bold"),
            fg_color="#00d9ff",
            text_color="#0a1628",
            corner_radius=10,
            height=45,
            command=self.on_new_trip
        )
        new_trip_btn.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        
        # Load Trip button
        load_trip_btn = ctk.CTkButton(
            actions_frame,
            text="📂 Load Trip",
            font=("Helvetica", 13, "bold"),
            fg_color="#00a8cc",
            text_color="#ffffff",
            corner_radius=10,
            height=45,
            command=self.on_load_trip
        )
        load_trip_btn.grid(row=0, column=1, sticky="ew", padx=5)
        
        # Compare Trips button
        compare_btn = ctk.CTkButton(
            actions_frame,
            text="📊 Compare",
            font=("Helvetica", 13, "bold"),
            fg_color="#0081b4",
            text_color="#ffffff",
            corner_radius=10,
            height=45,
            command=lambda: messagebox.showinfo("Compare", "Feature coming soon!")
        )
        compare_btn.grid(row=0, column=2, sticky="ew", padx=5)
        
        # Settings button
        settings_btn = ctk.CTkButton(
            actions_frame,
            text="⚙️ Settings",
            font=("Helvetica", 13, "bold"),
            fg_color="#005a8d",
            text_color="#ffffff",
            corner_radius=10,
            height=45,
            command=lambda: messagebox.showinfo("Settings", "Settings coming soon!")
        )
        settings_btn.grid(row=0, column=3, sticky="ew", padx=(5, 0))
    
    def _create_upcoming_trips(self, parent):
        """Create upcoming trips section"""
        section_frame = ctk.CTkFrame(parent, fg_color="transparent")
        section_frame.grid(row=3, column=0, sticky="ew", pady=(0, 20))
        section_frame.grid_columnconfigure(0, weight=1)
        
        # Section title
        title = ctk.CTkLabel(
            section_frame,
            text="📅 Upcoming Trips",
            font=("Helvetica", 16, "bold"),
            text_color="#00d9ff"
        )
        title.grid(row=0, column=0, sticky="w", pady=(0, 15))
        
        # Sample upcoming trips
        trips = [
            {
                "name": "Mumbai to Delhi",
                "date": "2026-06-15",
                "duration": "5 days",
                "status": "Planned"
            },
            {
                "name": "Bangalore to Chennai",
                "date": "2026-07-20",
                "duration": "3 days",
                "status": "In Planning"
            }
        ]
        
        for idx, trip in enumerate(trips):
            trip_card = self._create_trip_card(section_frame, trip)
            trip_card.grid(row=idx+1, column=0, sticky="ew", pady=10)
    
    def _create_trip_card(self, parent, trip: Dict) -> ctk.CTkFrame:
        """Create a trip card"""
        card = ctk.CTkFrame(parent, fg_color="#1a1a1a", corner_radius=12)
        card.grid_columnconfigure(0, weight=1)
        
        # Trip info
        info_frame = ctk.CTkFrame(card, fg_color="transparent")
        info_frame.grid(row=0, column=0, sticky="ew", padx=15, pady=15)
        info_frame.grid_columnconfigure(0, weight=1)
        
        # Trip name
        name_label = ctk.CTkLabel(
            info_frame,
            text=trip["name"],
            font=("Helvetica", 14, "bold"),
            text_color="#ffffff"
        )
        name_label.grid(row=0, column=0, sticky="w")
        
        # Trip details
        details_text = f"📅 {trip['date']} • ⏱️ {trip['duration']} • Status: {trip['status']}"
        details_label = ctk.CTkLabel(
            info_frame,
            text=details_text,
            font=("Helvetica", 11),
            text_color="#888888"
        )
        details_label.grid(row=1, column=0, sticky="w", pady=(5, 0))
        
        # View button
        view_btn = ctk.CTkButton(
            info_frame,
            text="View →",
            font=("Helvetica", 11, "bold"),
            fg_color="#00d9ff",
            text_color="#0a1628",
            width=80,
            height=30,
            corner_radius=8,
            command=self.on_view_trip
        )
        view_btn.grid(row=0, column=1, rowspan=2, padx=(10, 0))
        
        return card
    
    def _create_recommendations(self, parent):
        """Create AI recommendations section"""
        section_frame = ctk.CTkFrame(parent, fg_color="transparent")
        section_frame.grid(row=4, column=0, sticky="ew", pady=(0, 20))
        section_frame.grid_columnconfigure(0, weight=1)
        
        # Section title
        title = ctk.CTkLabel(
            section_frame,
            text="💡 AI Recommendations",
            font=("Helvetica", 16, "bold"),
            text_color="#00d9ff"
        )
        title.grid(row=0, column=0, sticky="w", pady=(0, 15))
        
        # Sample recommendations
        recommendations = [
            "🌤️ Great weather expected in Bangalore next week",
            "✈️ Flight prices dropping for Mumbai-Delhi route",
            "🏨 New luxury hotels opened in Hyderabad",
            "🍽️ Try the famous biryani at Hyderabad",
            "🎫 Book Taj Mahal tickets in advance"
        ]
        
        for idx, rec in enumerate(recommendations):
            rec_label = ctk.CTkLabel(
                section_frame,
                text=rec,
                font=("Helvetica", 11),
                text_color="#888888",
                wraplength=500,
                justify="left"
            )
            rec_label.grid(row=idx+1, column=0, sticky="w", pady=8)
    
    def update_stats(self, stats: TravelStatistics):
        """Update statistics display"""
        # This would update the stats section with real data
        pass
    
    def add_upcoming_trip(self, trip: TripItinerary):
        """Add upcoming trip to display"""
        pass
    
    def add_recommendation(self, recommendation: str):
        """Add recommendation to display"""
        pass


class TripPlannerWindow(ctk.CTkFrame):
    """Main trip planner window"""
    
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.setup_ui()
    
    def setup_ui(self):
        """Setup main window UI"""
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self)
        self.notebook.grid(row=0, column=0, sticky="nsew")
        
        # Dashboard tab
        dashboard_frame = ctk.CTkFrame(self.notebook)
        self.notebook.add(dashboard_frame, text="Dashboard")
        
        self.dashboard = EnhancedDashboard(
            dashboard_frame,
            on_new_trip=self.on_new_trip,
            on_load_trip=self.on_load_trip,
            on_view_trip=self.on_view_trip
        )
        self.dashboard.pack(fill="both", expand=True)
    
    def on_new_trip(self):
        """Handle new trip creation"""
        messagebox.showinfo("New Trip", "Opening trip planner...")
    
    def on_load_trip(self):
        """Handle loading trip"""
        messagebox.showinfo("Load Trip", "Loading saved trips...")
    
    def on_view_trip(self):
        """Handle viewing trip"""
        messagebox.showinfo("View Trip", "Displaying trip details...")
