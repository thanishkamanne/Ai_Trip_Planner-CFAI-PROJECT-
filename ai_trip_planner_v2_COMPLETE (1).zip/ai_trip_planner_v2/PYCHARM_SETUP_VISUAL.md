# PyCharm Setup - Complete Visual Guide
## AI-Powered Smart Trip Planner (Python 3.14 Compatible)

---

## ✅ STEP 1: VERIFY PYTHON 3.14 INSTALLATION

### 1.1 Open Command Prompt / Terminal

**Windows:**
- Press `Win + R`
- Type: `cmd`
- Press Enter

**macOS:**
- Press `Cmd + Space`
- Type: `terminal`
- Press Enter

**Linux:**
- Press `Ctrl + Alt + T`

### 1.2 Check Python Version

**Type this command:**
```bash
python --version
```

**Expected Output:**
```
Python 3.14.0
```

**If you get "Python not found":**
- Download from https://www.python.org/downloads/
- Install Python 3.14
- Make sure to check "Add Python to PATH" during installation

---

## ✅ STEP 2: DOWNLOAD & EXTRACT PROJECT

### 2.1 Extract ZIP File

**Windows (File Manager):**
1. Right-click `ai_trip_planner_v2_complete.zip`
2. Select "Extract All..."
3. Choose destination (e.g., Desktop or Documents)
4. Click "Extract"

**Result:**
```
ai_trip_planner_v2/
├── main.py
├── requirements.txt
├── engine/
├── gui/
└── data/
```

---

## ✅ STEP 3: OPEN PROJECT IN PYCHARM

### 3.1 Launch PyCharm

**Windows/macOS/Linux:**
- Open PyCharm application
- Or download from https://www.jetbrains.com/pycharm/

### 3.2 Open Project

**In PyCharm:**
1. Click **File** → **Open**
2. Navigate to `ai_trip_planner_v2` folder
3. Click **Open**

**PyCharm Window:**
```
┌─────────────────────────────────────────────────────────┐
│ PyCharm                                          _ □ X  │
├─────────────────────────────────────────────────────────┤
│ File Edit View Navigate Source Refactor Tools VCS Help  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Project Structure (Left Panel):                       │
│  ├─ ai_trip_planner_v2                                │
│  │  ├─ main.py                                        │
│  │  ├─ requirements.txt                               │
│  │  ├─ README.md                                      │
│  │  ├─ engine/                                        │
│  │  │  ├─ __init__.py                                │
│  │  │  ├─ models.py                                  │
│  │  │  ├─ itinerary_generator.py                     │
│  │  │  ├─ transport_engine.py                        │
│  │  │  ├─ ai_insights.py                             │
│  │  │  └─ trip_manager.py                            │
│  │  ├─ gui/                                          │
│  │  │  ├─ __init__.py                                │
│  │  │  └─ enhanced_dashboard.py                      │
│  │  ├─ data/                                         │
│  │  │  └─ trips/                                     │
│  │  └─ [other files]                                 │
│  │                                                   │
│  [Code Editor Area - Center]                         │
│  [Terminal - Bottom]                                 │
│                                                     │
└─────────────────────────────────────────────────────────┘
```

### 3.3 Trust the Project

**If prompted:**
- Click "Trust Project"
- This allows PyCharm to analyze the code

---

## ✅ STEP 4: CONFIGURE PYTHON INTERPRETER

### 4.1 Open Interpreter Settings

**In PyCharm:**
1. Click **File** → **Settings** (Windows/Linux)
   - Or **PyCharm** → **Preferences** (macOS)

**Settings Window:**
```
┌─────────────────────────────────────────────────────────┐
│ Settings                                         _ □ X  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Left Panel:                                            │
│ ├─ Project: ai_trip_planner_v2                        │
│ │  ├─ Python Interpreter  ← CLICK HERE               │
│ │  ├─ Project Structure                               │
│ │  └─ ...                                              │
│                                                         │
│ Right Panel:                                           │
│ [Shows interpreter options]                           │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 4.2 Select Python Interpreter

**In Python Interpreter section:**
1. Click the **gear icon** ⚙️
2. Select **Add...**

**Add Python Interpreter:**
```
┌─────────────────────────────────────────────────────────┐
│ Add Python Interpreter                         _ □ X  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ ◉ Existing Environment                                │
│ ○ New Environment                                     │
│ ○ WSL                                                 │
│                                                         │
│ Interpreter path: [Browse...]                        │
│                                                         │
│ [Cancel]  [OK]                                        │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 4.3 Browse Python Executable

**Click "Browse...":**
1. Navigate to your Python 3.14 installation
2. Select `python.exe` (Windows) or `python3` (macOS/Linux)

**Common Paths:**
- **Windows:** `C:\Users\YourUsername\AppData\Local\Programs\Python\Python314\python.exe`
- **macOS:** `/usr/local/bin/python3`
- **Linux:** `/usr/bin/python3`

3. Click **OK**

---

## ✅ STEP 5: INSTALL DEPENDENCIES

### 5.1 Open Terminal in PyCharm

**In PyCharm:**
1. Click **View** → **Tool Windows** → **Terminal**
   - Or press `Alt + F12`

**Terminal appears at bottom:**
```
┌─────────────────────────────────────────────────────────┐
│ Terminal                                                │
├─────────────────────────────────────────────────────────┤
│ C:\path\to\ai_trip_planner_v2>                         │
│                                                         │
│ (cursor blinking here)                                 │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 5.2 Install Dependencies

**Type this command:**
```bash
pip install -r requirements.txt
```

**Press Enter and wait...**

**Expected Output:**
```
Collecting customtkinter
  Downloading customtkinter-5.2.0-py3-none-win_amd64.whl
Installing collected packages: customtkinter, networkx, matplotlib
Successfully installed customtkinter-5.2.0
Successfully installed networkx-3.2.1
Successfully installed matplotlib-3.8.2
```

### 5.3 Verify Installation

**Type this command:**
```bash
pip list
```

**You should see:**
```
customtkinter       5.2.0
networkx            3.2.1
matplotlib          3.8.2
```

---

## ✅ STEP 6: CREATE DATA DIRECTORY

### 6.1 In Terminal

**Type this command:**

**Windows:**
```bash
mkdir data\trips
```

**macOS/Linux:**
```bash
mkdir -p data/trips
```

**Expected Output:**
```
(No output = success)
```

### 6.2 Verify in PyCharm

**In Project Tree (Left Panel):**
1. Right-click on `ai_trip_planner_v2`
2. Click "Refresh"
3. You should see `data/trips/` folder

---

## ✅ STEP 7: RUN THE APPLICATION

### 7.1 Open main.py

**In PyCharm:**
1. Click on `main.py` in the project tree (left panel)
2. Code appears in editor (center)

**main.py in Editor:**
```python
"""
AI-Powered Smart Trip Planner - Enhanced Version
Complete travel planning application...
"""

import customtkinter as ctk
from tkinter import messagebox, ttk
...

class SmartTripPlannerApp(ctk.CTk):
    """Main application class"""
    
    def __init__(self):
        super().__init__()
        ...
```

### 7.2 Run the Application

**Method 1: Click Run Button**
1. Look for the **▶️ Run** button (top right)
2. Click it

**Method 2: Right-click main.py**
1. Right-click `main.py` in project tree
2. Select "Run 'main.py'"

**Method 3: Keyboard Shortcut**
- Press `Shift + F10` (Windows/Linux)
- Press `Control + R` (macOS)

**PyCharm Shows:**
```
┌─────────────────────────────────────────────────────────┐
│ Run                                                     │
├─────────────────────────────────────────────────────────┤
│ Starting AI-Powered Smart Trip Planner...              │
│ GUI initialized successfully                           │
│ Waiting for user input...                              │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 7.3 Application Window Appears

**A new window opens:**
```
┌─────────────────────────────────────────────────────────┐
│ AI-Powered Smart Trip Planner                  _ □ X  │
├─────────────────────────────────────────────────────────┤
│ [Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics] │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  🏠 DASHBOARD                                          │
│  ═══════════════════════════════════════════════════   │
│                                                         │
│  📊 QUICK STATS                                        │
│  ┌─────────────┬─────────────┬─────────────┐          │
│  │ 📊 Trips: 0 │ 📍 Cities: 0 │ 💰 Spent: ₹0 │         │
│  └─────────────┴─────────────┴─────────────┘          │
│                                                         │
│  [✈️ New Trip] [📂 Load] [📊 Compare] [⚙️ Settings]   │
│                                                         │
│  📅 UPCOMING TRIPS                                     │
│  (No trips yet)                                        │
│                                                         │
│  💡 AI RECOMMENDATIONS                                 │
│  • Great weather expected in Bangalore next week       │
│  • Flight prices dropping for Mumbai-Delhi route       │
│  • New luxury hotels opened in Hyderabad               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

✅ **Application is running!**

---

## ✅ STEP 8: CREATE YOUR FIRST TRIP

### 8.1 Click "New Trip" Tab

**In the Application Window:**
```
┌─────────────────────────────────────────────────────────┐
│ AI-Powered Smart Trip Planner                  _ □ X  │
├─────────────────────────────────────────────────────────┤
│ [Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics] │
│                    ↑ CLICK HERE                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ✈️ Plan Your Perfect Trip                             │
│  ═══════════════════════════════════════════════════   │
│                                                         │
│  From City:        [Mumbai          ▼]                │
│  To City:          [Delhi           ▼]                │
│  Start Date:       [2026-06-15     ]                  │
│  Duration:         [5              ]                  │
│  Budget:           [75000          ]                  │
│  Transport Mode:   [flight         ▼]                │
│  Comfort Level:    [comfort        ▼]                │
│  Risk Tolerance:   [0.5            ]                  │
│  Interests:        [sightseeing,food,culture]         │
│                                                         │
│  [🚀 Generate Itinerary]                              │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 8.2 Fill in Trip Details

**Step by step:**

1. **From City:** Click dropdown → Select **Mumbai**
2. **To City:** Click dropdown → Select **Delhi**
3. **Start Date:** Click field → Type **2026-06-15**
4. **Duration:** Click field → Type **5**
5. **Budget:** Click field → Type **75000**
6. **Transport Mode:** Click dropdown → Select **flight**
7. **Comfort Level:** Click dropdown → Select **comfort**
8. **Risk Tolerance:** Click field → Type **0.5**
9. **Interests:** Click field → Type **sightseeing,food,culture**

**Completed Form:**
```
From City:        Mumbai
To City:          Delhi
Start Date:       2026-06-15
Duration:         5
Budget:           75000
Transport Mode:   flight
Comfort Level:    comfort
Risk Tolerance:   0.5
Interests:        sightseeing,food,culture
```

### 8.3 Generate Itinerary

**Click the button:**
```
[🚀 Generate Itinerary]
```

**Wait 2-3 seconds...**

**Success Message:**
```
┌─────────────────────────────────────────────────────────┐
│ Information                                    _ □ X  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ✅ Itinerary generated successfully!                  │
│                                                         │
│  [OK]                                                  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Click OK**

---

## ✅ STEP 9: VIEW TRIP DETAILS

### 9.1 Trip Details Tab Opens Automatically

**You see:**
```
┌─────────────────────────────────────────────────────────┐
│ AI-Powered Smart Trip Planner                  _ □ X  │
├─────────────────────────────────────────────────────────┤
│ [Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics] │
│                            ↑ ACTIVE                     │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ════════════════════════════════════════════════════  │
│  ✈️ TRIP ITINERARY: Mumbai → Delhi                    │
│  ════════════════════════════════════════════════════  │
│                                                         │
│  📅 TRIP OVERVIEW                                      │
│  ─────────────────────────────────────────────────────  │
│  Trip ID: trip_20260607_143825                        │
│  Duration: 5 days (2026-06-15 to 2026-06-19)         │
│  Budget: ₹75,000                                      │
│  Total Cost: ₹72,000                                  │
│  Distance: 1400 km                                    │
│  Transport: FLIGHT                                    │
│  Comfort Level: COMFORT                               │
│                                                         │
│  ════════════════════════════════════════════════════  │
│  📋 DAY-BY-DAY ITINERARY                              │
│  ════════════════════════════════════════════════════  │
│                                                         │
│  📍 DAY 1 - 2026-06-15 (Mumbai)                       │
│  ─────────────────────────────────────────────────────  │
│  Activities:                                           │
│  • Breakfast at hotel                                 │
│  • Visit Gateway of India                            │
│  • Lunch at local restaurant                         │
│  • Explore Marine Drive                              │
│  • Dinner at Taj Mahal Palace                        │
│                                                         │
│  🏨 Hotels:                                            │
│  • Taj Mahal Palace - ₹12,000/night (Rating: 4.8/5)  │
│  • Oberoi Mumbai - ₹10,500/night (Rating: 4.7/5)     │
│  • Trident Mumbai - ₹9,500/night (Rating: 4.6/5)     │
│                                                         │
│  🎫 Attractions:                                       │
│  • Gateway of India - Historic monument (Rating: 4.9) │
│  • Marine Drive - Scenic coastal road (Rating: 4.8)   │
│  • Taj Mahal Palace - Luxury hotel tour (Rating: 4.7) │
│                                                         │
│  🍽️ Meals:                                             │
│  • Breakfast: Vada Pav                                │
│  • Lunch: Pav Bhaji                                   │
│  • Dinner: Seafood specialties                        │
│                                                         │
│  💰 Estimated Daily Budget: ₹15,000                   │
│                                                         │
│  [... scroll down to see more days ...]               │
│                                                         │
│  ════════════════════════════════════════════════════  │
│  💡 AI RECOMMENDATIONS                                 │
│  ════════════════════════════════════════════════════  │
│  • ✈️ Flight recommended for faster travel             │
│  • 🌤️ Check weather forecast for monsoon              │
│  • 🎫 Book attractions in advance                     │
│  • 🍽️ Try local street food for authentic experience  │
│  • 💵 Use public transport and eat at local restaurants│
│  • 🎫 Book popular attractions in advance              │
│  • 🏨 Confirm hotel bookings 24 hours before arrival   │
│                                                         │
│  [💾 Save Trip] [📄 Export PDF] [📤 Share]           │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 9.2 Scroll to See More

**Use scrollbar on right side to see:**
- Days 2, 3, 4, 5 itineraries
- More attractions
- More AI recommendations

---

## ✅ STEP 10: SAVE YOUR TRIP

### 10.1 Click Save Trip Button

**In Trip Details Tab:**
```
[💾 Save Trip] [📄 Export PDF] [📤 Share]
     ↑ CLICK HERE
```

**Success Message:**
```
┌─────────────────────────────────────────────────────────┐
│ Information                                    _ □ X  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ✅ Trip saved successfully!                           │
│  Trip ID: trip_20260607_143825                        │
│                                                         │
│  [OK]                                                  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Click OK**

---

## ✅ STEP 11: VIEW SAVED TRIPS

### 11.1 Click "Saved Trips" Tab

**In the Application:**
```
┌─────────────────────────────────────────────────────────┐
│ AI-Powered Smart Trip Planner                  _ □ X  │
├─────────────────────────────────────────────────────────┤
│ [Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics] │
│                                                ↑ CLICK  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  💾 SAVED TRIPS                                        │
│  ═══════════════════════════════════════════════════   │
│                                                         │
│  📍 Mumbai → Delhi                                     │
│     📅 2026-06-15 to 2026-06-19 (5 days)              │
│     💰 ₹72,000 / ₹75,000                              │
│     ✈️ FLIGHT                                          │
│     ID: trip_20260607_143825                          │
│  ────────────────────────────────────────────────────  │
│                                                         │
│  (You can add more trips here)                         │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## ✅ STEP 12: VIEW ANALYTICS

### 12.1 Click "Analytics" Tab

**In the Application:**
```
┌─────────────────────────────────────────────────────────┐
│ AI-Powered Smart Trip Planner                  _ □ X  │
├─────────────────────────────────────────────────────────┤
│ [Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics] │
│                                                         ↑ CLICK
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📊 TRAVEL ANALYTICS                                   │
│  ═══════════════════════════════════════════════════   │
│                                                         │
│  🌍 TRAVEL STATISTICS                                  │
│  ─────────────────────────────────────────────────────  │
│                                                         │
│  📊 Total Trips: 1                                     │
│  📍 Total Distance: 1400 km                            │
│  💰 Total Spent: ₹72,000                               │
│  ⏱️ Average Trip Duration: 5.0 days                    │
│                                                         │
│  🏙️ Favorite Cities: Delhi, Mumbai                     │
│  ✈️ Favorite Transport: flight                         │
│  🌍 Most Visited: Delhi                                │
│  🌱 Carbon Footprint: 210 kg CO2                       │
│                                                         │
│  ─────────────────────────────────────────────────────  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 🎉 YOU'RE DONE!

**Congratulations!** You have successfully:

✅ Installed Python 3.14
✅ Set up PyCharm
✅ Configured Python Interpreter
✅ Installed all dependencies
✅ Created data directory
✅ Ran the application
✅ Created your first trip (Mumbai → Delhi)
✅ Generated complete itinerary
✅ Saved the trip
✅ Viewed saved trips
✅ Checked analytics

---

## 🔄 CREATE MORE TRIPS

### Trip 2: Budget Beach Adventure
```
From City:        Bangalore
To City:          Goa
Start Date:       2026-07-01
Duration:         3
Budget:           40000
Transport Mode:   bus
Comfort Level:    budget
Risk Tolerance:   0.7
Interests:        beaches,food,nightlife
```

### Trip 3: Luxury City Tour
```
From City:        Delhi
To City:          Jaipur
Start Date:       2026-08-01
Duration:         4
Budget:           150000
Transport Mode:   flight
Comfort Level:    luxury
Risk Tolerance:   0.3
Interests:        culture,shopping,heritage
```

---

## 🆘 TROUBLESHOOTING

### Problem: "ModuleNotFoundError: No module named 'customtkinter'"

**Solution:**
1. Open Terminal in PyCharm (Alt + F12)
2. Type: `pip install customtkinter`
3. Wait for installation
4. Run again

### Problem: Application doesn't start

**Solution:**
1. Check Python version: `python --version`
2. Verify it's 3.14 or higher
3. Reinstall dependencies: `pip install -r requirements.txt --force-reinstall`
4. Try running again

### Problem: GUI appears blank

**Solution:**
1. Close the application
2. In PyCharm Terminal: `del __pycache__` (Windows) or `rm -rf __pycache__` (macOS/Linux)
3. Run again

### Problem: Data directory not found

**Solution:**
1. In PyCharm Terminal: `mkdir -p data/trips`
2. Run again

---

## 📚 NEXT STEPS

1. Create multiple trips with different preferences
2. Compare trips in "Saved Trips" tab
3. Explore all features
4. Customize the code for your needs
5. Read README.md for advanced features

---

## 🎓 PYTHON 3.14 COMPATIBILITY

✅ CustomTkinter - Fully compatible
✅ NetworkX - Fully compatible
✅ Matplotlib - Fully compatible
✅ All standard libraries - Fully compatible

No issues with Python 3.14!

---

**Happy Trip Planning!** ✈️🌍

For more help, check:
- README.md
- DOCUMENTATION.md
- QUICK_START.md
