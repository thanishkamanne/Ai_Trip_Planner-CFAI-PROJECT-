"""
AI Insights and Recommendations Engine
Generates intelligent travel insights and recommendations
"""

import random
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from engine.models import (
    TravelInsight, TripItinerary, TransportMode, ComfortLevel
)


class AIInsightsEngine:
    """Generates AI insights and recommendations"""
    
    def __init__(self):
        self.weather_patterns = self._load_weather_patterns()
        self.traffic_patterns = self._load_traffic_patterns()
        self.safety_data = self._load_safety_data()
    
    def _load_weather_patterns(self) -> Dict[str, List[str]]:
        """Load weather patterns for cities"""
        return {
            "Mumbai": ["Monsoon (Jun-Sep)", "Hot (Mar-May)", "Pleasant (Nov-Feb)"],
            "Delhi": ["Hot (Apr-Jun)", "Monsoon (Jul-Sep)", "Cold (Nov-Jan)"],
            "Bangalore": ["Moderate year-round", "Rainy (Jun-Sep)", "Pleasant (Oct-May)"],
            "Hyderabad": ["Hot (Apr-Jun)", "Rainy (Jun-Sep)", "Cool (Nov-Feb)"],
            "Chennai": ["Hot (Apr-May)", "Rainy (Oct-Dec)", "Moderate (Jan-Mar)"],
            "Pune": ["Moderate (Oct-May)", "Hot (Apr-Jun)", "Rainy (Jun-Sep)"],
            "Jaipur": ["Hot (Apr-Jun)", "Rainy (Jul-Sep)", "Cold (Nov-Jan)"],
            "Kochi": ["Hot (Mar-May)", "Rainy (Jun-Sep)", "Pleasant (Oct-Feb)"],
            "Kolkata": ["Hot (Apr-Jun)", "Rainy (Jul-Sep)", "Cool (Nov-Feb)"],
            "Ahmedabad": ["Hot (Apr-Jun)", "Rainy (Jul-Sep)", "Pleasant (Oct-Mar)"],
        }
    
    def _load_traffic_patterns(self) -> Dict[str, Dict]:
        """Load traffic patterns"""
        return {
            "Mumbai": {"peak_hours": "8-10 AM, 5-8 PM", "congestion_level": "High", "avg_speed": "20 km/h"},
            "Delhi": {"peak_hours": "7-10 AM, 4-8 PM", "congestion_level": "Very High", "avg_speed": "15 km/h"},
            "Bangalore": {"peak_hours": "8-11 AM, 5-9 PM", "congestion_level": "High", "avg_speed": "25 km/h"},
            "Hyderabad": {"peak_hours": "8-10 AM, 5-8 PM", "congestion_level": "Medium", "avg_speed": "30 km/h"},
            "Chennai": {"peak_hours": "8-10 AM, 5-8 PM", "congestion_level": "Medium", "avg_speed": "25 km/h"},
            "Pune": {"peak_hours": "8-10 AM, 5-8 PM", "congestion_level": "Medium", "avg_speed": "28 km/h"},
            "Jaipur": {"peak_hours": "8-10 AM, 5-8 PM", "congestion_level": "Low", "avg_speed": "35 km/h"},
            "Kochi": {"peak_hours": "8-10 AM, 5-8 PM", "congestion_level": "Low", "avg_speed": "30 km/h"},
            "Kolkata": {"peak_hours": "8-10 AM, 5-8 PM", "congestion_level": "High", "avg_speed": "20 km/h"},
            "Ahmedabad": {"peak_hours": "8-10 AM, 5-8 PM", "congestion_level": "Low", "avg_speed": "32 km/h"},
        }
    
    def _load_safety_data(self) -> Dict[str, float]:
        """Load safety scores for cities (1-10, higher is safer)"""
        return {
            "Mumbai": 7.5,
            "Delhi": 6.5,
            "Bangalore": 8.0,
            "Hyderabad": 8.2,
            "Chennai": 8.5,
            "Pune": 8.3,
            "Jaipur": 7.8,
            "Kochi": 9.0,
            "Kolkata": 7.2,
            "Ahmedabad": 8.1,
        }
    
    def generate_insights(self, itinerary: TripItinerary) -> List[TravelInsight]:
        """Generate comprehensive travel insights"""
        insights = []
        
        # Weather insights
        weather_insights = self._generate_weather_insights(itinerary)
        insights.extend(weather_insights)
        
        # Traffic insights
        traffic_insights = self._generate_traffic_insights(itinerary)
        insights.extend(traffic_insights)
        
        # Safety insights
        safety_insights = self._generate_safety_insights(itinerary)
        insights.extend(safety_insights)
        
        # Budget insights
        budget_insights = self._generate_budget_insights(itinerary)
        insights.extend(budget_insights)
        
        # Transport insights
        transport_insights = self._generate_transport_insights(itinerary)
        insights.extend(transport_insights)
        
        return insights
    
    def _generate_weather_insights(self, itinerary: TripItinerary) -> List[TravelInsight]:
        """Generate weather-related insights"""
        insights = []
        
        # Check destination weather
        if itinerary.destination in self.weather_patterns:
            patterns = self.weather_patterns[itinerary.destination]
            weather_condition = random.choice(patterns)
            
            if "Monsoon" in weather_condition:
                insights.append(TravelInsight(
                    insight_type="weather",
                    title="🌧️ Monsoon Season Alert",
                    description=f"Heavy rainfall expected in {itinerary.destination}. Pack waterproof gear and plan indoor activities.",
                    severity="medium",
                    action_recommended="Carry umbrella and waterproof clothing",
                    affected_cities=[itinerary.destination],
                    timestamp=datetime.now().isoformat()
                ))
            elif "Hot" in weather_condition:
                insights.append(TravelInsight(
                    insight_type="weather",
                    title="🌡️ High Temperature Alert",
                    description=f"Very hot weather in {itinerary.destination}. Stay hydrated and avoid outdoor activities during peak hours.",
                    severity="medium",
                    action_recommended="Drink plenty of water, use sunscreen",
                    affected_cities=[itinerary.destination],
                    timestamp=datetime.now().isoformat()
                ))
            else:
                insights.append(TravelInsight(
                    insight_type="weather",
                    title="✅ Pleasant Weather",
                    description=f"Great weather expected in {itinerary.destination}. Perfect for outdoor sightseeing!",
                    severity="low",
                    action_recommended="Plan outdoor activities",
                    affected_cities=[itinerary.destination],
                    timestamp=datetime.now().isoformat()
                ))
        
        return insights
    
    def _generate_traffic_insights(self, itinerary: TripItinerary) -> List[TravelInsight]:
        """Generate traffic-related insights"""
        insights = []
        
        for city in [itinerary.source, itinerary.destination]:
            if city in self.traffic_patterns:
                traffic = self.traffic_patterns[city]
                
                if traffic["congestion_level"] == "Very High":
                    insights.append(TravelInsight(
                        insight_type="traffic",
                        title="🚗 Heavy Traffic Alert",
                        description=f"Severe traffic congestion expected in {city}. Peak hours: {traffic['peak_hours']}. Plan travel accordingly.",
                        severity="high",
                        action_recommended="Avoid peak hours, use public transport",
                        affected_cities=[city],
                        timestamp=datetime.now().isoformat()
                    ))
                elif traffic["congestion_level"] == "High":
                    insights.append(TravelInsight(
                        insight_type="traffic",
                        title="🚗 Traffic Congestion",
                        description=f"Moderate to heavy traffic in {city}. Peak hours: {traffic['peak_hours']}.",
                        severity="medium",
                        action_recommended="Plan travel outside peak hours",
                        affected_cities=[city],
                        timestamp=datetime.now().isoformat()
                    ))
        
        return insights
    
    def _generate_safety_insights(self, itinerary: TripItinerary) -> List[TravelInsight]:
        """Generate safety-related insights"""
        insights = []
        
        destination_safety = self.safety_data.get(itinerary.destination, 7.0)
        
        if destination_safety >= 8.5:
            insights.append(TravelInsight(
                insight_type="safety",
                title="✅ Safe Destination",
                description=f"{itinerary.destination} is a safe destination with good infrastructure and security.",
                severity="low",
                action_recommended="Enjoy your trip with normal precautions",
                affected_cities=[itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        elif destination_safety >= 7.5:
            insights.append(TravelInsight(
                insight_type="safety",
                title="🛡️ Generally Safe",
                description=f"{itinerary.destination} is generally safe. Follow standard travel precautions.",
                severity="low",
                action_recommended="Keep valuables secure, avoid isolated areas at night",
                affected_cities=[itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        else:
            insights.append(TravelInsight(
                insight_type="safety",
                title="⚠️ Safety Precautions Recommended",
                description=f"Exercise extra caution in {itinerary.destination}. Stick to well-traveled areas.",
                severity="medium",
                action_recommended="Stay in well-lit areas, use registered taxis",
                affected_cities=[itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        
        return insights
    
    def _generate_budget_insights(self, itinerary: TripItinerary) -> List[TravelInsight]:
        """Generate budget-related insights"""
        insights = []
        
        daily_budget = itinerary.budget / itinerary.duration_days
        actual_daily_cost = itinerary.total_cost / itinerary.duration_days if itinerary.total_cost > 0 else 0
        
        if actual_daily_cost > daily_budget * 1.2:
            insights.append(TravelInsight(
                insight_type="budget",
                title="💰 Budget Alert",
                description=f"Trip cost (₹{itinerary.total_cost:.0f}) exceeds budget by {((actual_daily_cost/daily_budget - 1) * 100):.0f}%.",
                severity="high",
                action_recommended="Consider budget hotels or reduce activities",
                affected_cities=[itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        elif actual_daily_cost > daily_budget:
            insights.append(TravelInsight(
                insight_type="budget",
                title="💰 Budget Slightly Over",
                description=f"Trip cost slightly exceeds budget. Consider cost-saving options.",
                severity="medium",
                action_recommended="Look for budget alternatives",
                affected_cities=[itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        else:
            insights.append(TravelInsight(
                insight_type="budget",
                title="✅ Within Budget",
                description=f"Trip cost (₹{itinerary.total_cost:.0f}) is within your budget.",
                severity="low",
                action_recommended="You have room for additional activities",
                affected_cities=[itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        
        return insights
    
    def _generate_transport_insights(self, itinerary: TripItinerary) -> List[TravelInsight]:
        """Generate transport-related insights"""
        insights = []
        
        if itinerary.transport_preference == TransportMode.FLIGHT:
            insights.append(TravelInsight(
                insight_type="recommendation",
                title="✈️ Flight Recommendation",
                description="Flying is the fastest option. Book in advance for better rates.",
                severity="low",
                action_recommended="Book flights 2-3 weeks in advance",
                affected_cities=[itinerary.source, itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        elif itinerary.transport_preference == TransportMode.TRAIN:
            insights.append(TravelInsight(
                insight_type="recommendation",
                title="🚂 Train Journey",
                description="Train travel offers scenic views and comfort. Book early for better seats.",
                severity="low",
                action_recommended="Book train tickets in advance",
                affected_cities=[itinerary.source, itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        elif itinerary.transport_preference == TransportMode.BUS:
            insights.append(TravelInsight(
                insight_type="recommendation",
                title="🚌 Budget-Friendly Bus",
                description="Bus travel is economical and connects many cities. Bring entertainment for long journeys.",
                severity="low",
                action_recommended="Book through reliable operators",
                affected_cities=[itinerary.source, itinerary.destination],
                timestamp=datetime.now().isoformat()
            ))
        
        return insights
    
    def get_smart_recommendations(self, itinerary: TripItinerary) -> List[str]:
        """Get smart AI recommendations"""
        recommendations = []
        
        # Packing recommendations
        if itinerary.destination in self.weather_patterns:
            patterns = self.weather_patterns[itinerary.destination]
            if any("Monsoon" in p for p in patterns):
                recommendations.append("🎒 Pack: Waterproof bag, umbrella, water-resistant clothing")
            elif any("Hot" in p for p in patterns):
                recommendations.append("🎒 Pack: Light clothing, sunscreen, hat, water bottle")
            else:
                recommendations.append("🎒 Pack: Comfortable clothing, light jacket")
        
        # Activity recommendations
        if itinerary.duration_days <= 2:
            recommendations.append("📸 Focus on main attractions due to short duration")
        elif itinerary.duration_days <= 4:
            recommendations.append("📸 Mix popular attractions with local experiences")
        else:
            recommendations.append("📸 Explore both famous sites and hidden gems")
        
        # Timing recommendations
        recommendations.append("⏰ Start early to maximize sightseeing time")
        
        # Food recommendations
        recommendations.append("🍽️ Try local street food for authentic experience")
        
        # Money recommendations
        if itinerary.budget < 30000:
            recommendations.append("💵 Use public transport and eat at local restaurants")
        elif itinerary.budget < 100000:
            recommendations.append("💵 Mix budget and comfort options")
        else:
            recommendations.append("💵 Enjoy premium experiences and dining")
        
        # Booking recommendations
        recommendations.append("🎫 Book popular attractions in advance")
        recommendations.append("🏨 Confirm hotel bookings 24 hours before arrival")
        
        return recommendations[:8]  # Return top 8 recommendations
