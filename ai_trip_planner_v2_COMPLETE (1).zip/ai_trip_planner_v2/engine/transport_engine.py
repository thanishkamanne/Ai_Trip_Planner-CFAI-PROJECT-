"""
Transport Options and Recommendations Engine
Manages multiple transport modes and intelligent recommendations
"""

import random
from typing import List, Dict, Tuple, Optional
from engine.models import TransportOption, TransportMode, ComfortLevel


class TransportEngine:
    """Manages transport options and recommendations"""
    
    def __init__(self):
        self.transport_data = self._load_transport_data()
        self.distance_matrix = self._load_distance_matrix()
    
    def _load_transport_data(self) -> Dict[str, Dict[TransportMode, Dict]]:
        """Load transport characteristics"""
        return {
            "Mumbai-Delhi": {
                TransportMode.FLIGHT: {
                    "travel_time": 2.5,
                    "base_cost": 4000,
                    "comfort_score": 8.5,
                    "risk_level": 0.1,
                    "availability": 0.95,
                    "co2_emissions": 150,
                    "convenience_score": 9.0
                },
                TransportMode.TRAIN: {
                    "travel_time": 16,
                    "base_cost": 1500,
                    "comfort_score": 6.5,
                    "risk_level": 0.15,
                    "availability": 0.90,
                    "co2_emissions": 80,
                    "convenience_score": 7.0
                },
                TransportMode.BUS: {
                    "travel_time": 24,
                    "base_cost": 800,
                    "comfort_score": 5.0,
                    "risk_level": 0.25,
                    "availability": 0.85,
                    "co2_emissions": 60,
                    "convenience_score": 5.5
                },
                TransportMode.CAB: {
                    "travel_time": 30,
                    "base_cost": 12000,
                    "comfort_score": 7.5,
                    "risk_level": 0.20,
                    "availability": 0.80,
                    "co2_emissions": 200,
                    "convenience_score": 6.5
                }
            },
            "Delhi-Bangalore": {
                TransportMode.FLIGHT: {
                    "travel_time": 3.0,
                    "base_cost": 5000,
                    "comfort_score": 8.5,
                    "risk_level": 0.1,
                    "availability": 0.95,
                    "co2_emissions": 180,
                    "convenience_score": 9.0
                },
                TransportMode.TRAIN: {
                    "travel_time": 36,
                    "base_cost": 2500,
                    "comfort_score": 6.0,
                    "risk_level": 0.15,
                    "availability": 0.88,
                    "co2_emissions": 120,
                    "convenience_score": 6.5
                },
                TransportMode.BUS: {
                    "travel_time": 48,
                    "base_cost": 1200,
                    "comfort_score": 4.5,
                    "risk_level": 0.30,
                    "availability": 0.82,
                    "co2_emissions": 90,
                    "convenience_score": 4.5
                },
                TransportMode.CAB: {
                    "travel_time": 40,
                    "base_cost": 18000,
                    "comfort_score": 7.0,
                    "risk_level": 0.25,
                    "availability": 0.75,
                    "co2_emissions": 300,
                    "convenience_score": 6.0
                }
            },
            "Mumbai-Hyderabad": {
                TransportMode.FLIGHT: {
                    "travel_time": 1.5,
                    "base_cost": 3000,
                    "comfort_score": 8.5,
                    "risk_level": 0.1,
                    "availability": 0.93,
                    "co2_emissions": 100,
                    "convenience_score": 9.0
                },
                TransportMode.TRAIN: {
                    "travel_time": 14,
                    "base_cost": 1200,
                    "comfort_score": 6.5,
                    "risk_level": 0.15,
                    "availability": 0.91,
                    "co2_emissions": 70,
                    "convenience_score": 7.5
                },
                TransportMode.BUS: {
                    "travel_time": 18,
                    "base_cost": 600,
                    "comfort_score": 5.5,
                    "risk_level": 0.20,
                    "availability": 0.87,
                    "co2_emissions": 50,
                    "convenience_score": 6.0
                },
                TransportMode.CAB: {
                    "travel_time": 16,
                    "base_cost": 8000,
                    "comfort_score": 7.5,
                    "risk_level": 0.18,
                    "availability": 0.85,
                    "co2_emissions": 150,
                    "convenience_score": 7.0
                }
            },
            "Bangalore-Chennai": {
                TransportMode.FLIGHT: {
                    "travel_time": 1.0,
                    "base_cost": 2500,
                    "comfort_score": 8.5,
                    "risk_level": 0.1,
                    "availability": 0.92,
                    "co2_emissions": 80,
                    "convenience_score": 9.0
                },
                TransportMode.TRAIN: {
                    "travel_time": 5,
                    "base_cost": 500,
                    "comfort_score": 7.0,
                    "risk_level": 0.12,
                    "availability": 0.94,
                    "co2_emissions": 40,
                    "convenience_score": 8.5
                },
                TransportMode.BUS: {
                    "travel_time": 6,
                    "base_cost": 300,
                    "comfort_score": 6.0,
                    "risk_level": 0.15,
                    "availability": 0.90,
                    "co2_emissions": 30,
                    "convenience_score": 7.0
                },
                TransportMode.CAB: {
                    "travel_time": 5.5,
                    "base_cost": 4000,
                    "comfort_score": 8.0,
                    "risk_level": 0.14,
                    "availability": 0.88,
                    "co2_emissions": 100,
                    "convenience_score": 8.0
                }
            }
        }
    
    def _load_distance_matrix(self) -> Dict[Tuple[str, str], float]:
        """Load distance matrix between cities"""
        return {
            ("Mumbai", "Delhi"): 1400,
            ("Delhi", "Mumbai"): 1400,
            ("Delhi", "Bangalore"): 2150,
            ("Bangalore", "Delhi"): 2150,
            ("Mumbai", "Hyderabad"): 700,
            ("Hyderabad", "Mumbai"): 700,
            ("Bangalore", "Chennai"): 350,
            ("Chennai", "Bangalore"): 350,
            ("Mumbai", "Pune"): 150,
            ("Pune", "Mumbai"): 150,
            ("Delhi", "Jaipur"): 260,
            ("Jaipur", "Delhi"): 260,
            ("Hyderabad", "Bangalore"): 500,
            ("Bangalore", "Hyderabad"): 500,
        }
    
    def get_transport_options(self, from_city: str, to_city: str,
                             budget: float, comfort_pref: ComfortLevel,
                             risk_tolerance: float) -> List[TransportOption]:
        """Get available transport options"""
        route_key = f"{from_city}-{to_city}"
        
        if route_key not in self.transport_data:
            # Generate default options
            return self._generate_default_options(from_city, to_city, budget)
        
        transport_data = self.transport_data[route_key]
        options = []
        
        for mode, data in transport_data.items():
            # Adjust cost based on comfort preference
            cost_multiplier = self._get_cost_multiplier(comfort_pref)
            adjusted_cost = data["base_cost"] * cost_multiplier
            
            # Check if within budget
            if adjusted_cost <= budget * 1.5:  # Allow 50% over budget
                option = TransportOption(
                    mode=mode,
                    travel_time_hours=data["travel_time"],
                    cost=adjusted_cost,
                    comfort_score=data["comfort_score"],
                    risk_level=data["risk_level"],
                    availability=data["availability"],
                    co2_emissions=data["co2_emissions"],
                    convenience_score=data["convenience_score"]
                )
                options.append(option)
        
        # Sort by value score
        options.sort(key=lambda x: self._calculate_value_score(x, budget, risk_tolerance),
                    reverse=True)
        
        return options
    
    def _generate_default_options(self, from_city: str, to_city: str,
                                 budget: float) -> List[TransportOption]:
        """Generate default transport options"""
        distance = random.uniform(200, 2000)
        
        options = [
            TransportOption(
                mode=TransportMode.FLIGHT,
                travel_time_hours=random.uniform(1.5, 4),
                cost=min(5000, budget * 0.8),
                comfort_score=8.5,
                risk_level=0.1,
                availability=0.95,
                co2_emissions=150,
                convenience_score=9.0
            ),
            TransportOption(
                mode=TransportMode.TRAIN,
                travel_time_hours=random.uniform(8, 24),
                cost=min(2000, budget * 0.4),
                comfort_score=6.5,
                risk_level=0.15,
                availability=0.90,
                co2_emissions=80,
                convenience_score=7.5
            ),
            TransportOption(
                mode=TransportMode.BUS,
                travel_time_hours=random.uniform(12, 36),
                cost=min(1000, budget * 0.2),
                comfort_score=5.0,
                risk_level=0.25,
                availability=0.85,
                co2_emissions=60,
                convenience_score=6.0
            ),
            TransportOption(
                mode=TransportMode.CAB,
                travel_time_hours=random.uniform(10, 30),
                cost=min(15000, budget * 1.2),
                comfort_score=7.5,
                risk_level=0.20,
                availability=0.80,
                co2_emissions=200,
                convenience_score=7.0
            )
        ]
        
        return options
    
    def _get_cost_multiplier(self, comfort: ComfortLevel) -> float:
        """Get cost multiplier based on comfort preference"""
        multipliers = {
            ComfortLevel.BUDGET: 0.8,
            ComfortLevel.STANDARD: 1.0,
            ComfortLevel.COMFORT: 1.3,
            ComfortLevel.LUXURY: 1.6
        }
        return multipliers.get(comfort, 1.0)
    
    def _calculate_value_score(self, option: TransportOption, budget: float,
                              risk_tolerance: float) -> float:
        """Calculate value score for a transport option"""
        # Weighted scoring
        budget_score = (1 - (option.cost / budget)) * 20 if option.cost <= budget else -10
        comfort_score = option.comfort_score * 2
        time_score = (1 - (option.travel_time_hours / 48)) * 15  # Normalize to 48 hours
        risk_score = (1 - option.risk_level) * 10 * risk_tolerance
        availability_score = option.availability * 10
        convenience_score = option.convenience_score * 1.5
        
        total_score = (budget_score + comfort_score + time_score +
                      risk_score + availability_score + convenience_score)
        
        return max(0, total_score)
    
    def recommend_transport(self, from_city: str, to_city: str,
                           budget: float, comfort_pref: ComfortLevel,
                           risk_tolerance: float, trip_duration: int) -> Dict:
        """Get AI recommendation for best transport"""
        options = self.get_transport_options(from_city, to_city, budget,
                                            comfort_pref, risk_tolerance)
        
        if not options:
            return {"recommendation": "No suitable transport found", "options": []}
        
        best_option = options[0]
        
        # Generate recommendation text
        recommendation_text = f"🚀 Recommended: {best_option.mode.value.upper()}\n"
        recommendation_text += f"   Cost: ₹{best_option.cost:.0f}\n"
        recommendation_text += f"   Duration: {best_option.travel_time_hours:.1f} hours\n"
        recommendation_text += f"   Comfort: {best_option.comfort_score}/10\n"
        
        # Add reasoning
        if best_option.mode == TransportMode.FLIGHT:
            recommendation_text += "   Why: Fastest option, good comfort level"
        elif best_option.mode == TransportMode.TRAIN:
            recommendation_text += "   Why: Best value, scenic journey"
        elif best_option.mode == TransportMode.BUS:
            recommendation_text += "   Why: Most economical option"
        else:
            recommendation_text += "   Why: Maximum comfort and flexibility"
        
        return {
            "recommendation": recommendation_text,
            "best_option": best_option,
            "all_options": options,
            "reasoning": self._generate_reasoning(best_option, options, budget)
        }
    
    def _generate_reasoning(self, best: TransportOption, all_options: List[TransportOption],
                           budget: float) -> List[str]:
        """Generate reasoning for recommendation"""
        reasoning = []
        
        if best.cost <= budget * 0.5:
            reasoning.append("✅ Well within budget")
        elif best.cost <= budget:
            reasoning.append("✅ Within budget")
        else:
            reasoning.append("⚠️ Slightly over budget but worth it")
        
        if best.comfort_score >= 8:
            reasoning.append("✅ High comfort level")
        elif best.comfort_score >= 6:
            reasoning.append("✅ Good comfort level")
        else:
            reasoning.append("⚠️ Basic comfort level")
        
        if best.travel_time_hours <= 6:
            reasoning.append("✅ Quick travel")
        elif best.travel_time_hours <= 24:
            reasoning.append("✅ Reasonable travel time")
        else:
            reasoning.append("⚠️ Long travel time")
        
        if best.risk_level <= 0.15:
            reasoning.append("✅ Safe travel option")
        
        return reasoning
