"""
Itinerary Generation Engine
Generates complete day-by-day trip plans based on user preferences
"""

import random
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional
from engine.models import (
    TripItinerary, DayItinerary, TravelSegment, Hotel, Attraction,
    TransportMode, ComfortLevel, AttractionType
)


class ItineraryGenerator:
    """Generates complete trip itineraries"""
    
    def __init__(self):
        self.attractions_db = self._load_attractions_db()
        self.hotels_db = self._load_hotels_db()
        self.meal_suggestions = self._load_meal_suggestions()
    
    def _load_attractions_db(self) -> Dict[str, List[Attraction]]:
        """Load attractions database for Indian cities"""
        attractions = {
            "Mumbai": [
                Attraction("Gateway of India", "Mumbai", AttractionType.MONUMENT, 
                          "Iconic arch monument", 4.5, 0, 1.5, "morning", 2.0, 9.5),
                Attraction("Marine Drive", "Mumbai", AttractionType.NATURE,
                          "Scenic coastal drive", 4.3, 0, 2.0, "evening", 3.0, 9.0),
                Attraction("Taj Mahal Palace Hotel", "Mumbai", AttractionType.CULTURAL,
                          "Historic luxury hotel", 4.4, 0, 1.0, "afternoon", 2.5, 8.5),
                Attraction("Colaba Causeway", "Mumbai", AttractionType.SHOPPING,
                          "Shopping and food street", 4.2, 0, 3.0, "evening", 2.0, 8.0),
                Attraction("Chowpatty Beach", "Mumbai", AttractionType.ENTERTAINMENT,
                          "Popular beach destination", 4.0, 0, 2.5, "evening", 1.5, 8.5),
            ],
            "Delhi": [
                Attraction("India Gate", "Delhi", AttractionType.MONUMENT,
                          "War memorial monument", 4.6, 0, 1.5, "morning", 3.0, 9.8),
                Attraction("Red Fort", "Delhi", AttractionType.MONUMENT,
                          "Historic fort complex", 4.4, 200, 2.5, "morning", 2.0, 9.5),
                Attraction("Jama Masjid", "Delhi", AttractionType.CULTURAL,
                          "Historic mosque", 4.3, 0, 1.5, "morning", 1.0, 8.5),
                Attraction("Chandni Chowk", "Delhi", AttractionType.SHOPPING,
                          "Historic market", 4.1, 0, 3.0, "afternoon", 0.5, 8.0),
                Attraction("Qutub Minar", "Delhi", AttractionType.MONUMENT,
                          "Ancient minaret", 4.5, 250, 1.5, "afternoon", 15.0, 9.0),
            ],
            "Bangalore": [
                Attraction("Vidhana Soudha", "Bangalore", AttractionType.MONUMENT,
                          "Government building", 4.4, 0, 1.5, "morning", 1.0, 8.5),
                Attraction("Cubbon Park", "Bangalore", AttractionType.NATURE,
                          "Urban park", 4.3, 0, 2.0, "morning", 0.5, 8.0),
                Attraction("Bangalore Palace", "Bangalore", AttractionType.CULTURAL,
                          "Historic palace", 4.2, 300, 2.0, "afternoon", 5.0, 8.0),
                Attraction("MG Road", "Bangalore", AttractionType.SHOPPING,
                          "Shopping district", 4.1, 0, 3.0, "afternoon", 0.0, 7.5),
                Attraction("Nandi Hills", "Bangalore", AttractionType.NATURE,
                          "Hill station", 4.5, 0, 3.0, "morning", 60.0, 9.0),
            ],
            "Hyderabad": [
                Attraction("Charminar", "Hyderabad", AttractionType.MONUMENT,
                          "Historic monument", 4.5, 0, 1.5, "morning", 0.0, 9.5),
                Attraction("Golconda Fort", "Hyderabad", AttractionType.MONUMENT,
                          "Historic fort", 4.4, 100, 2.5, "morning", 11.0, 9.0),
                Attraction("Hussain Sagar Lake", "Hyderabad", AttractionType.NATURE,
                          "Scenic lake", 4.2, 0, 2.0, "evening", 2.0, 8.0),
                Attraction("Laad Bazaar", "Hyderabad", AttractionType.SHOPPING,
                          "Traditional market", 4.1, 0, 2.5, "afternoon", 0.5, 8.0),
                Attraction("Ramoji Film City", "Hyderabad", AttractionType.ENTERTAINMENT,
                          "Film studio theme park", 4.3, 500, 4.0, "morning", 30.0, 8.5),
            ],
            "Chennai": [
                Attraction("Marina Beach", "Chennai", AttractionType.NATURE,
                          "Long sandy beach", 4.2, 0, 2.5, "evening", 0.0, 8.0),
                Attraction("Kapaleeshwarar Temple", "Chennai", AttractionType.CULTURAL,
                          "Ancient temple", 4.4, 0, 1.5, "morning", 2.0, 8.5),
                Attraction("Fort St. George", "Chennai", AttractionType.MONUMENT,
                          "Historic fort", 4.1, 100, 2.0, "morning", 1.0, 7.5),
                Attraction("San Thome Cathedral", "Chennai", AttractionType.CULTURAL,
                          "Historic cathedral", 4.2, 0, 1.0, "afternoon", 2.0, 7.5),
                Attraction("Parthasarathy Temple", "Chennai", AttractionType.CULTURAL,
                          "Ancient temple", 4.3, 0, 1.5, "morning", 5.0, 8.0),
            ],
        }
        return attractions
    
    def _load_hotels_db(self) -> Dict[str, List[Hotel]]:
        """Load hotels database"""
        hotels = {
            "Mumbai": [
                Hotel("Taj Hotel Mumbai", "Mumbai", 15000, 4.8, ComfortLevel.LUXURY,
                      2.0, 9.5, ["WiFi", "Gym", "Restaurant", "Spa"], 0.95),
                Hotel("ITC Maratha", "Mumbai", 12000, 4.6, ComfortLevel.LUXURY,
                      8.0, 9.0, ["WiFi", "Gym", "Pool", "Restaurant"], 0.90),
                Hotel("The Oberoi Mumbai", "Mumbai", 11000, 4.7, ComfortLevel.COMFORT,
                      3.0, 9.2, ["WiFi", "Gym", "Restaurant"], 0.92),
                Hotel("Marriott Mumbai", "Mumbai", 8000, 4.4, ComfortLevel.COMFORT,
                      5.0, 8.8, ["WiFi", "Gym", "Restaurant"], 0.88),
                Hotel("Ibis Mumbai", "Mumbai", 3500, 3.8, ComfortLevel.STANDARD,
                      4.0, 7.5, ["WiFi", "Restaurant"], 0.85),
            ],
            "Delhi": [
                Hotel("The Oberoi Delhi", "Delhi", 14000, 4.7, ComfortLevel.LUXURY,
                      8.0, 9.3, ["WiFi", "Gym", "Pool", "Spa"], 0.93),
                Hotel("ITC Maurya", "Delhi", 13000, 4.6, ComfortLevel.LUXURY,
                      10.0, 9.1, ["WiFi", "Gym", "Restaurant"], 0.91),
                Hotel("Hilton Delhi", "Delhi", 7500, 4.3, ComfortLevel.COMFORT,
                      6.0, 8.5, ["WiFi", "Gym", "Restaurant"], 0.87),
                Hotel("Radisson Blu Delhi", "Delhi", 6500, 4.2, ComfortLevel.COMFORT,
                      5.0, 8.3, ["WiFi", "Restaurant"], 0.86),
                Hotel("Budget Hotel Delhi", "Delhi", 2000, 3.5, ComfortLevel.BUDGET,
                      3.0, 6.5, ["WiFi"], 0.80),
            ],
            "Bangalore": [
                Hotel("Leela Palace Bangalore", "Bangalore", 12000, 4.8, ComfortLevel.LUXURY,
                      10.0, 9.4, ["WiFi", "Gym", "Pool", "Spa"], 0.94),
                Hotel("St. Mark's Hotel", "Bangalore", 8000, 4.4, ComfortLevel.COMFORT,
                      5.0, 8.6, ["WiFi", "Gym", "Restaurant"], 0.88),
                Hotel("Taj West End", "Bangalore", 9000, 4.5, ComfortLevel.COMFORT,
                      3.0, 8.8, ["WiFi", "Gym", "Pool"], 0.89),
                Hotel("Ibis Bangalore", "Bangalore", 3000, 3.7, ComfortLevel.STANDARD,
                      2.0, 7.2, ["WiFi", "Restaurant"], 0.84),
                Hotel("Budget Inn Bangalore", "Bangalore", 1500, 3.4, ComfortLevel.BUDGET,
                      4.0, 6.0, ["WiFi"], 0.78),
            ],
            "Hyderabad": [
                Hotel("Taj Falaknuma Palace", "Hyderabad", 16000, 4.9, ComfortLevel.LUXURY,
                      15.0, 9.6, ["WiFi", "Gym", "Pool", "Spa"], 0.96),
                Hotel("ITC Kohinoor", "Hyderabad", 10000, 4.5, ComfortLevel.COMFORT,
                      8.0, 8.9, ["WiFi", "Gym", "Restaurant"], 0.90),
                Hotel("Novotel Hyderabad", "Hyderabad", 5500, 4.1, ComfortLevel.STANDARD,
                      6.0, 8.0, ["WiFi", "Restaurant"], 0.85),
                Hotel("Budget Hotel Hyderabad", "Hyderabad", 1800, 3.5, ComfortLevel.BUDGET,
                      5.0, 6.8, ["WiFi"], 0.80),
            ],
            "Chennai": [
                Hotel("Taj Coromandel", "Chennai", 11000, 4.6, ComfortLevel.LUXURY,
                      3.0, 9.2, ["WiFi", "Gym", "Pool", "Spa"], 0.92),
                Hotel("The Leela Chennai", "Chennai", 10000, 4.7, ComfortLevel.LUXURY,
                      5.0, 9.3, ["WiFi", "Gym", "Beach Access"], 0.93),
                Hotel("Radisson Blu Chennai", "Chennai", 6000, 4.2, ComfortLevel.COMFORT,
                      4.0, 8.4, ["WiFi", "Gym"], 0.87),
                Hotel("Budget Hotel Chennai", "Chennai", 1600, 3.4, ComfortLevel.BUDGET,
                      3.0, 6.5, ["WiFi"], 0.79),
            ],
        }
        return hotels
    
    def _load_meal_suggestions(self) -> Dict[str, Dict[str, List[str]]]:
        """Load meal suggestions for cities"""
        return {
            "Mumbai": {
                "breakfast": ["Vada Pav", "Poha", "Misal Pav", "Idli", "Dosa"],
                "lunch": ["Pav Bhaji", "Biryani", "Thali", "Seafood Curry", "Butter Chicken"],
                "dinner": ["Seafood at Mahim Causeway", "Street Food Tour", "Restaurant Dinner", "Beach Snacks"]
            },
            "Delhi": {
                "breakfast": ["Aloo Paratha", "Chole Bhature", "Jalebi", "Halwa Puri", "Dosa"],
                "lunch": ["Butter Chicken", "Biryani", "Paneer Tikka", "Dal Makhani", "Tandoori Chicken"],
                "dinner": ["Chandni Chowk Food Tour", "Restaurant Dinner", "Street Food", "Kebabs"]
            },
            "Bangalore": {
                "breakfast": ["Idli Sambar", "Dosa", "Uttapam", "Upma", "Poha"],
                "lunch": ["Biryani", "Thali", "Ragi Mudde", "Paneer Curry", "Seafood"],
                "dinner": ["Restaurant Dinner", "Street Food", "Café Culture", "Coastal Cuisine"]
            },
            "Hyderabad": {
                "breakfast": ["Haleem", "Nihari", "Puri", "Idli", "Dosa"],
                "lunch": ["Hyderabadi Biryani", "Haleem", "Kebabs", "Nihari", "Thali"],
                "dinner": ["Biryani Night", "Kebab Tour", "Restaurant Dinner", "Street Food"]
            },
            "Chennai": {
                "breakfast": ["Idli", "Dosa", "Appam", "Puttu", "Upma"],
                "lunch": ["Chettinad Cuisine", "Seafood Curry", "Biryani", "Thali", "Rasam Rice"],
                "dinner": ["Beach Dinner", "Restaurant Dinner", "Street Food", "Seafood Specialties"]
            },
        }
    
    def generate_itinerary(self, trip_params: Dict) -> TripItinerary:
        """Generate complete trip itinerary"""
        source = trip_params.get("source", "Mumbai")
        destination = trip_params.get("destination", "Delhi")
        start_date = trip_params.get("start_date", datetime.now().strftime("%Y-%m-%d"))
        duration_days = trip_params.get("duration_days", 5)
        budget = trip_params.get("budget", 50000)
        transport_preference = trip_params.get("transport_preference", TransportMode.FLIGHT)
        comfort_preference = trip_params.get("comfort_preference", ComfortLevel.STANDARD)
        risk_tolerance = trip_params.get("risk_tolerance", 0.5)
        user_interests = trip_params.get("user_interests", ["sightseeing", "food", "culture"])
        
        # Calculate end date
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = start_dt + timedelta(days=duration_days - 1)
        end_date = end_dt.strftime("%Y-%m-%d")
        
        # Create itinerary object
        trip_id = f"trip_{int(datetime.now().timestamp())}"
        itinerary = TripItinerary(
            trip_id=trip_id,
            source=source,
            destination=destination,
            start_date=start_date,
            end_date=end_date,
            duration_days=duration_days,
            budget=budget,
            transport_preference=transport_preference,
            comfort_preference=comfort_preference,
            risk_tolerance=risk_tolerance,
            user_interests=user_interests,
            created_at=datetime.now().isoformat(),
            modified_at=datetime.now().isoformat()
        )
        
        # Generate day-by-day itinerary
        current_date = start_dt
        cities_to_visit = self._plan_route(source, destination, duration_days)
        
        for day_num in range(1, duration_days + 1):
            current_city = cities_to_visit[min(day_num - 1, len(cities_to_visit) - 1)]
            day_itinerary = self._generate_day_itinerary(
                day_num, current_date.strftime("%Y-%m-%d"), current_city,
                comfort_preference, user_interests, budget / duration_days
            )
            itinerary.days.append(day_itinerary)
            current_date += timedelta(days=1)
        
        # Calculate totals and add AI recommendations
        itinerary.total_cost = sum(day.estimated_budget for day in itinerary.days)
        itinerary.ai_recommendations = self._generate_recommendations(itinerary)
        
        return itinerary
    
    def _plan_route(self, source: str, destination: str, duration: int) -> List[str]:
        """Plan route between cities"""
        # Simplified route planning
        major_routes = {
            ("Mumbai", "Delhi"): ["Mumbai", "Pune", "Indore", "Delhi"],
            ("Delhi", "Mumbai"): ["Delhi", "Indore", "Pune", "Mumbai"],
            ("Bangalore", "Chennai"): ["Bangalore", "Vellore", "Chennai"],
            ("Chennai", "Bangalore"): ["Chennai", "Vellore", "Bangalore"],
            ("Mumbai", "Hyderabad"): ["Mumbai", "Pune", "Hyderabad"],
            ("Hyderabad", "Mumbai"): ["Hyderabad", "Pune", "Mumbai"],
        }
        
        route_key = (source, destination)
        if route_key in major_routes:
            route = major_routes[route_key]
        else:
            route = [source, destination]
        
        # Adjust route based on duration
        if duration <= 2:
            return [source, destination]
        elif duration <= 3:
            return route[:2] + [destination]
        else:
            return route[:min(len(route), duration)]
    
    def _generate_day_itinerary(self, day_num: int, date: str, city: str,
                               comfort: ComfortLevel, interests: List[str],
                               daily_budget: float) -> DayItinerary:
        """Generate itinerary for a single day"""
        day = DayItinerary(
            day_number=day_num,
            date=date,
            city=city,
            estimated_budget=daily_budget
        )
        
        # Add activities
        day.activities = [
            "Breakfast at local café",
            "Morning sightseeing",
            "Lunch at restaurant",
            "Afternoon activities",
            "Dinner and evening walk"
        ]
        
        # Add hotel recommendations
        if city in self.hotels_db:
            hotels = self.hotels_db[city]
            # Filter by comfort preference
            filtered_hotels = [h for h in hotels if h.comfort_level.value >= comfort.value]
            if filtered_hotels:
                day.hotels = random.sample(filtered_hotels, min(3, len(filtered_hotels)))
            else:
                day.hotels = hotels[:3]
        
        # Add attractions
        if city in self.attractions_db:
            attractions = self.attractions_db[city]
            # Filter by interests
            relevant_attractions = []
            for attr in attractions:
                if any(interest.lower() in attr.attraction_type.value.lower() for interest in interests):
                    relevant_attractions.append(attr)
            
            if not relevant_attractions:
                relevant_attractions = attractions
            
            day.attractions = random.sample(relevant_attractions, min(3, len(relevant_attractions)))
        
        # Add meals
        if city in self.meal_suggestions:
            meals = self.meal_suggestions[city]
            day.meals = {
                "breakfast": random.choice(meals.get("breakfast", ["Local Breakfast"])),
                "lunch": random.choice(meals.get("lunch", ["Local Lunch"])),
                "dinner": random.choice(meals.get("dinner", ["Local Dinner"]))
            }
        
        return day
    
    def _generate_recommendations(self, itinerary: TripItinerary) -> List[str]:
        """Generate AI recommendations"""
        recommendations = []
        
        # Budget recommendations
        if itinerary.total_cost > itinerary.budget * 1.1:
            recommendations.append(f"⚠️ Budget Alert: Trip cost (₹{itinerary.total_cost:.0f}) exceeds budget by {((itinerary.total_cost/itinerary.budget - 1) * 100):.0f}%")
        
        # Transport recommendations
        if itinerary.transport_preference == TransportMode.FLIGHT:
            recommendations.append("✈️ Flight recommended for faster travel and comfort")
        elif itinerary.transport_preference == TransportMode.TRAIN:
            recommendations.append("🚂 Train travel offers scenic views and affordability")
        
        # Weather recommendations
        recommendations.append("🌤️ Check weather forecast before departure")
        
        # Safety recommendations
        if itinerary.risk_tolerance < 0.3:
            recommendations.append("🛡️ Avoid high-risk areas; stick to well-traveled routes")
        
        # Activity recommendations
        recommendations.append("📸 Book popular attractions in advance during peak season")
        recommendations.append("🍽️ Try local cuisine at recommended restaurants")
        
        return recommendations[:5]  # Return top 5 recommendations
