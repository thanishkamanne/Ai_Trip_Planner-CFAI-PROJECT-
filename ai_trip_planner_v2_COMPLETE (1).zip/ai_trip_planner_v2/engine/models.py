"""
Enhanced Data Models for AI-Powered Smart Trip Planner
Includes itinerary, transport, hotel, and attraction systems
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum
from datetime import datetime, timedelta
import json


class TransportMode(Enum):
    """Available transport modes"""
    FLIGHT = "flight"
    TRAIN = "train"
    BUS = "bus"
    CAB = "cab"


class ComfortLevel(Enum):
    """Comfort levels for hotels and transport"""
    BUDGET = "budget"
    STANDARD = "standard"
    COMFORT = "comfort"
    LUXURY = "luxury"


class AttractionType(Enum):
    """Types of attractions"""
    MONUMENT = "monument"
    NATURE = "nature"
    FOOD = "food"
    ENTERTAINMENT = "entertainment"
    SHOPPING = "shopping"
    CULTURAL = "cultural"


@dataclass
class TransportOption:
    """Represents a transport option between cities"""
    mode: TransportMode
    travel_time_hours: float
    cost: float
    comfort_score: float  # 1-10
    risk_level: float  # 0-1 (0 = safe, 1 = risky)
    availability: float  # 0-1 (availability percentage)
    co2_emissions: float  # kg
    convenience_score: float  # 1-10
    
    def to_dict(self) -> Dict:
        return {
            "mode": self.mode.value,
            "travel_time_hours": self.travel_time_hours,
            "cost": self.cost,
            "comfort_score": self.comfort_score,
            "risk_level": self.risk_level,
            "availability": self.availability,
            "co2_emissions": self.co2_emissions,
            "convenience_score": self.convenience_score
        }


@dataclass
class Hotel:
    """Represents a hotel in a city"""
    name: str
    city: str
    price_per_night: float
    rating: float  # 1-5
    comfort_level: ComfortLevel
    distance_from_center_km: float
    safety_score: float  # 1-10
    amenities: List[str] = field(default_factory=list)
    availability: float = 0.9  # 0-1
    
    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "city": self.city,
            "price_per_night": self.price_per_night,
            "rating": self.rating,
            "comfort_level": self.comfort_level.value,
            "distance_from_center_km": self.distance_from_center_km,
            "safety_score": self.safety_score,
            "amenities": self.amenities,
            "availability": self.availability
        }


@dataclass
class Attraction:
    """Represents a tourist attraction"""
    name: str
    city: str
    attraction_type: AttractionType
    description: str
    rating: float  # 1-5
    entry_fee: float
    duration_hours: float
    best_time: str  # e.g., "morning", "afternoon", "evening"
    distance_from_center_km: float
    popularity_score: float  # 1-10
    
    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "city": self.city,
            "attraction_type": self.attraction_type.value,
            "description": self.description,
            "rating": self.rating,
            "entry_fee": self.entry_fee,
            "duration_hours": self.duration_hours,
            "best_time": self.best_time,
            "distance_from_center_km": self.distance_from_center_km,
            "popularity_score": self.popularity_score
        }


@dataclass
class DayItinerary:
    """Represents a single day in the trip"""
    day_number: int
    date: str  # YYYY-MM-DD format
    city: str
    activities: List[str] = field(default_factory=list)
    hotels: List[Hotel] = field(default_factory=list)
    attractions: List[Attraction] = field(default_factory=list)
    meals: Dict[str, str] = field(default_factory=dict)  # breakfast, lunch, dinner
    travel_segment: Optional['TravelSegment'] = None
    estimated_budget: float = 0.0
    notes: str = ""
    
    def to_dict(self) -> Dict:
        return {
            "day_number": self.day_number,
            "date": self.date,
            "city": self.city,
            "activities": self.activities,
            "hotels": [h.to_dict() for h in self.hotels],
            "attractions": [a.to_dict() for a in self.attractions],
            "meals": self.meals,
            "travel_segment": self.travel_segment.to_dict() if self.travel_segment else None,
            "estimated_budget": self.estimated_budget,
            "notes": self.notes
        }


@dataclass
class TravelSegment:
    """Represents a travel segment between two cities"""
    from_city: str
    to_city: str
    transport_mode: TransportMode
    departure_time: str  # HH:MM format
    arrival_time: str  # HH:MM format
    cost: float
    duration_hours: float
    distance_km: float
    
    def to_dict(self) -> Dict:
        return {
            "from_city": self.from_city,
            "to_city": self.to_city,
            "transport_mode": self.transport_mode.value,
            "departure_time": self.departure_time,
            "arrival_time": self.arrival_time,
            "cost": self.cost,
            "duration_hours": self.duration_hours,
            "distance_km": self.distance_km
        }


@dataclass
class TripItinerary:
    """Complete trip itinerary"""
    trip_id: str
    source: str
    destination: str
    start_date: str  # YYYY-MM-DD
    end_date: str  # YYYY-MM-DD
    duration_days: int
    budget: float
    transport_preference: TransportMode
    comfort_preference: ComfortLevel
    risk_tolerance: float  # 0-1
    user_interests: List[str] = field(default_factory=list)
    days: List[DayItinerary] = field(default_factory=list)
    total_cost: float = 0.0
    total_distance_km: float = 0.0
    ai_recommendations: List[str] = field(default_factory=list)
    created_at: str = ""
    modified_at: str = ""
    
    def to_dict(self) -> Dict:
        return {
            "trip_id": self.trip_id,
            "source": self.source,
            "destination": self.destination,
            "start_date": self.start_date,
            "end_date": self.end_date,
            "duration_days": self.duration_days,
            "budget": self.budget,
            "transport_preference": self.transport_preference.value,
            "comfort_preference": self.comfort_preference.value,
            "risk_tolerance": self.risk_tolerance,
            "user_interests": self.user_interests,
            "days": [d.to_dict() for d in self.days],
            "total_cost": self.total_cost,
            "total_distance_km": self.total_distance_km,
            "ai_recommendations": self.ai_recommendations,
            "created_at": self.created_at,
            "modified_at": self.modified_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'TripItinerary':
        """Create TripItinerary from dictionary"""
        itinerary = cls(
            trip_id=data.get("trip_id", ""),
            source=data.get("source", ""),
            destination=data.get("destination", ""),
            start_date=data.get("start_date", ""),
            end_date=data.get("end_date", ""),
            duration_days=data.get("duration_days", 0),
            budget=data.get("budget", 0.0),
            transport_preference=TransportMode(data.get("transport_preference", "bus")),
            comfort_preference=ComfortLevel(data.get("comfort_preference", "standard")),
            risk_tolerance=data.get("risk_tolerance", 0.5),
            user_interests=data.get("user_interests", []),
            total_cost=data.get("total_cost", 0.0),
            total_distance_km=data.get("total_distance_km", 0.0),
            ai_recommendations=data.get("ai_recommendations", []),
            created_at=data.get("created_at", ""),
            modified_at=data.get("modified_at", "")
        )
        return itinerary


@dataclass
class TravelInsight:
    """AI-generated travel insight"""
    insight_type: str  # "weather", "traffic", "budget", "safety", "recommendation"
    title: str
    description: str
    severity: str  # "low", "medium", "high"
    action_recommended: Optional[str] = None
    affected_cities: List[str] = field(default_factory=list)
    timestamp: str = ""
    
    def to_dict(self) -> Dict:
        return {
            "insight_type": self.insight_type,
            "title": self.title,
            "description": self.description,
            "severity": self.severity,
            "action_recommended": self.action_recommended,
            "affected_cities": self.affected_cities,
            "timestamp": self.timestamp
        }


@dataclass
class TravelStatistics:
    """Travel statistics for dashboard"""
    total_trips: int = 0
    total_distance_traveled: float = 0.0
    total_money_spent: float = 0.0
    favorite_cities: List[str] = field(default_factory=list)
    favorite_transport_mode: Optional[TransportMode] = None
    average_trip_duration: float = 0.0
    most_visited_city: Optional[str] = None
    carbon_footprint: float = 0.0  # kg CO2
    
    def to_dict(self) -> Dict:
        return {
            "total_trips": self.total_trips,
            "total_distance_traveled": self.total_distance_traveled,
            "total_money_spent": self.total_money_spent,
            "favorite_cities": self.favorite_cities,
            "favorite_transport_mode": self.favorite_transport_mode.value if self.favorite_transport_mode else None,
            "average_trip_duration": self.average_trip_duration,
            "most_visited_city": self.most_visited_city,
            "carbon_footprint": self.carbon_footprint
        }
