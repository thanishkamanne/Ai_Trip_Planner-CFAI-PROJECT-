"""
Trip Management System
Handles saving, loading, and managing trips
"""

import json
import os
from datetime import datetime
from typing import List, Dict, Optional
from engine.models import TripItinerary, TravelStatistics


class TripManager:
    """Manages trip storage and retrieval"""
    
    def __init__(self, storage_dir: str = "data/trips"):
        self.storage_dir = storage_dir
        os.makedirs(storage_dir, exist_ok=True)
        self.stats_file = os.path.join(storage_dir, "statistics.json")
    
    def save_trip(self, itinerary: TripItinerary) -> bool:
        """Save trip to storage"""
        try:
            trip_file = os.path.join(self.storage_dir, f"{itinerary.trip_id}.json")
            with open(trip_file, 'w') as f:
                json.dump(itinerary.to_dict(), f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving trip: {e}")
            return False
    
    def load_trip(self, trip_id: str) -> Optional[TripItinerary]:
        """Load trip from storage"""
        try:
            trip_file = os.path.join(self.storage_dir, f"{trip_id}.json")
            if not os.path.exists(trip_file):
                return None
            
            with open(trip_file, 'r') as f:
                data = json.load(f)
            
            return TripItinerary.from_dict(data)
        except Exception as e:
            print(f"Error loading trip: {e}")
            return None
    
    def get_all_trips(self) -> List[TripItinerary]:
        """Get all saved trips"""
        trips = []
        try:
            for filename in os.listdir(self.storage_dir):
                if filename.endswith(".json") and filename != "statistics.json":
                    trip_id = filename.replace(".json", "")
                    trip = self.load_trip(trip_id)
                    if trip:
                        trips.append(trip)
        except Exception as e:
            print(f"Error loading trips: {e}")
        
        return sorted(trips, key=lambda x: x.created_at, reverse=True)
    
    def delete_trip(self, trip_id: str) -> bool:
        """Delete a trip"""
        try:
            trip_file = os.path.join(self.storage_dir, f"{trip_id}.json")
            if os.path.exists(trip_file):
                os.remove(trip_file)
                return True
            return False
        except Exception as e:
            print(f"Error deleting trip: {e}")
            return False
    
    def get_trip_summary(self, trip: TripItinerary) -> Dict:
        """Get summary of a trip"""
        return {
            "trip_id": trip.trip_id,
            "source": trip.source,
            "destination": trip.destination,
            "start_date": trip.start_date,
            "end_date": trip.end_date,
            "duration_days": trip.duration_days,
            "total_cost": trip.total_cost,
            "budget": trip.budget,
            "transport_mode": trip.transport_preference.value,
            "comfort_level": trip.comfort_preference.value,
            "created_at": trip.created_at,
            "days_count": len(trip.days)
        }
    
    def compare_trips(self, trip_ids: List[str]) -> Dict:
        """Compare multiple trips"""
        trips = [self.load_trip(tid) for tid in trip_ids]
        trips = [t for t in trips if t is not None]
        
        if not trips:
            return {}
        
        comparison = {
            "trips": [],
            "cost_comparison": {},
            "duration_comparison": {},
            "budget_efficiency": {}
        }
        
        for trip in trips:
            summary = self.get_trip_summary(trip)
            comparison["trips"].append(summary)
            
            # Cost comparison
            comparison["cost_comparison"][trip.trip_id] = trip.total_cost
            
            # Duration comparison
            comparison["duration_comparison"][trip.trip_id] = trip.duration_days
            
            # Budget efficiency (cost per day)
            efficiency = trip.total_cost / trip.duration_days if trip.duration_days > 0 else 0
            comparison["budget_efficiency"][trip.trip_id] = efficiency
        
        return comparison
    
    def update_statistics(self, trip: TripItinerary) -> bool:
        """Update travel statistics"""
        try:
            stats = self._load_statistics()
            
            stats["total_trips"] += 1
            stats["total_distance_traveled"] += trip.total_distance_km
            stats["total_money_spent"] += trip.total_cost
            stats["average_trip_duration"] = (
                (stats["average_trip_duration"] * (stats["total_trips"] - 1) + trip.duration_days) /
                stats["total_trips"]
            )
            
            # Update favorite cities
            if trip.destination not in stats["favorite_cities"]:
                stats["favorite_cities"].append(trip.destination)
            
            # Update most visited city
            city_visits = {}
            for t in self.get_all_trips():
                city_visits[t.destination] = city_visits.get(t.destination, 0) + 1
            
            if city_visits:
                stats["most_visited_city"] = max(city_visits, key=city_visits.get)
            
            # Update favorite transport mode
            transport_modes = {}
            for t in self.get_all_trips():
                mode = t.transport_preference.value
                transport_modes[mode] = transport_modes.get(mode, 0) + 1
            
            if transport_modes:
                favorite_mode = max(transport_modes, key=transport_modes.get)
                stats["favorite_transport_mode"] = favorite_mode
            
            # Estimate carbon footprint
            stats["carbon_footprint"] += trip.total_distance_km * 0.15  # kg CO2 per km
            
            self._save_statistics(stats)
            return True
        except Exception as e:
            print(f"Error updating statistics: {e}")
            return False
    
    def get_statistics(self) -> TravelStatistics:
        """Get travel statistics"""
        stats_dict = self._load_statistics()
        return TravelStatistics(
            total_trips=stats_dict.get("total_trips", 0),
            total_distance_traveled=stats_dict.get("total_distance_traveled", 0),
            total_money_spent=stats_dict.get("total_money_spent", 0),
            favorite_cities=stats_dict.get("favorite_cities", []),
            favorite_transport_mode=stats_dict.get("favorite_transport_mode"),
            average_trip_duration=stats_dict.get("average_trip_duration", 0),
            most_visited_city=stats_dict.get("most_visited_city"),
            carbon_footprint=stats_dict.get("carbon_footprint", 0)
        )
    
    def _load_statistics(self) -> Dict:
        """Load statistics from file"""
        if os.path.exists(self.stats_file):
            try:
                with open(self.stats_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            "total_trips": 0,
            "total_distance_traveled": 0.0,
            "total_money_spent": 0.0,
            "favorite_cities": [],
            "favorite_transport_mode": None,
            "average_trip_duration": 0.0,
            "most_visited_city": None,
            "carbon_footprint": 0.0
        }
    
    def _save_statistics(self, stats: Dict) -> bool:
        """Save statistics to file"""
        try:
            with open(self.stats_file, 'w') as f:
                json.dump(stats, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving statistics: {e}")
            return False
    
    def get_trip_insights(self, trip: TripItinerary) -> Dict:
        """Get insights about a trip"""
        insights = {
            "cost_per_day": trip.total_cost / trip.duration_days if trip.duration_days > 0 else 0,
            "cost_per_km": trip.total_cost / trip.total_distance_km if trip.total_distance_km > 0 else 0,
            "budget_utilization": (trip.total_cost / trip.budget * 100) if trip.budget > 0 else 0,
            "days_count": len(trip.days),
            "hotels_count": sum(len(day.hotels) for day in trip.days),
            "attractions_count": sum(len(day.attractions) for day in trip.days),
            "avg_hotel_price": sum(sum(h.price_per_night for h in day.hotels) for day in trip.days) / 
                              (sum(len(day.hotels) for day in trip.days) or 1),
            "transport_mode": trip.transport_preference.value,
            "comfort_level": trip.comfort_preference.value,
            "risk_tolerance": trip.risk_tolerance
        }
        return insights
    
    def export_trip_to_pdf(self, trip_id: str, output_file: str) -> bool:
        """Export trip to PDF (placeholder for future implementation)"""
        trip = self.load_trip(trip_id)
        if not trip:
            return False
        
        # This would integrate with a PDF library like reportlab
        # For now, just export as JSON
        try:
            with open(output_file, 'w') as f:
                json.dump(trip.to_dict(), f, indent=2)
            return True
        except Exception as e:
            print(f"Error exporting trip: {e}")
            return False
