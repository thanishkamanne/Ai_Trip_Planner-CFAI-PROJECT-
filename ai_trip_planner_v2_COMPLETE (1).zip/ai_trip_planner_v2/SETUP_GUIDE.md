# AI-Powered Smart Trip Planner - Setup & Installation Guide

## 🎯 Quick Start (5 minutes)

### Windows
```bash
# 1. Navigate to project directory
cd ai_trip_planner_v2

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the application
python main.py
```

### macOS/Linux
```bash
# 1. Navigate to project directory
cd ai_trip_planner_v2

# 2. Install dependencies
pip3 install -r requirements.txt

# 3. Run the application
python3 main.py
```

## 📋 System Requirements

- **OS**: Windows 10+, macOS 10.12+, Linux (Ubuntu 18.04+)
- **Python**: 3.8 or higher
- **RAM**: 2GB minimum
- **Storage**: 500MB free space
- **Internet**: Optional (for future API integrations)

## 🔧 Detailed Installation

### Step 1: Install Python

#### Windows
1. Download Python from https://www.python.org/downloads/
2. Run installer
3. **IMPORTANT**: Check "Add Python to PATH"
4. Click "Install Now"

#### macOS
```bash
# Using Homebrew (recommended)
brew install python3
```

#### Linux (Ubuntu)
```bash
sudo apt-get update
sudo apt-get install python3 python3-pip
```

### Step 2: Verify Python Installation

```bash
python --version
# or
python3 --version
```

Should show Python 3.8 or higher.

### Step 3: Create Virtual Environment (Recommended)

#### Windows
```bash
python -m venv venv
venv\Scripts\activate
```

#### macOS/Linux
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 4: Install Dependencies

```bash
# Make sure you're in the project directory
cd ai_trip_planner_v2

# Install from requirements.txt
pip install -r requirements.txt
```

Or install individually:
```bash
pip install customtkinter
pip install networkx
pip install matplotlib
```

### Step 5: Create Data Directory

```bash
# Windows
mkdir data\trips

# macOS/Linux
mkdir -p data/trips
```

### Step 6: Run the Application

```bash
python main.py
# or
python3 main.py
```

## 🎨 PyCharm Setup

### Opening Project in PyCharm

1. **Open PyCharm**
2. **File → Open** → Select `ai_trip_planner_v2` folder
3. **Trust the project** when prompted

### Configuring Python Interpreter

1. **File → Settings** (Windows) or **PyCharm → Preferences** (macOS)
2. **Project → Python Interpreter**
3. **Add Interpreter → Add Local Interpreter**
4. **Existing Environment** → Browse to Python executable
5. Click **OK**

### Running from PyCharm

1. **Right-click** on `main.py`
2. **Run 'main.py'**

Or use keyboard shortcut: **Shift + F10** (Windows) or **Control + R** (macOS)

### Installing Packages in PyCharm

1. **File → Settings → Project → Python Interpreter**
2. Click **+** button
3. Search for package name
4. Click **Install Package**

## 🚀 Running the Application

### Command Line

```bash
# Navigate to project
cd ai_trip_planner_v2

# Run main application
python main.py
```

### Creating Shortcuts

#### Windows Desktop Shortcut
1. Right-click on Desktop
2. New → Shortcut
3. Location: `python.exe main.py`
4. Name: "Trip Planner"
5. Finish

#### macOS Application Alias
```bash
# Create an alias in Applications folder
ln -s /path/to/ai_trip_planner_v2/main.py ~/Applications/TripPlanner.app
```

#### Linux Desktop Entry
Create `~/.local/share/applications/tripplanner.desktop`:
```ini
[Desktop Entry]
Type=Application
Name=Trip Planner
Exec=python3 /path/to/ai_trip_planner_v2/main.py
Icon=flight
Categories=Travel;
```

## 🔍 Troubleshooting

### "Python is not recognized"

**Windows**:
1. Check if Python is in PATH
2. Reinstall Python with "Add Python to PATH" checked
3. Restart computer

**macOS/Linux**:
```bash
# Check if python3 is available
which python3

# If not found, install it
brew install python3  # macOS
sudo apt-get install python3  # Ubuntu
```

### "No module named 'customtkinter'"

```bash
# Ensure pip is using correct Python version
python -m pip install customtkinter

# Or use pip3
pip3 install customtkinter
```

### "Permission denied" (macOS/Linux)

```bash
# Make main.py executable
chmod +x main.py

# Run with python explicitly
python3 main.py
```

### Application window doesn't appear

1. Check if process is running: `ps aux | grep main.py`
2. Try running from terminal to see error messages
3. Ensure display server is running (Linux)

### "Cannot find data directory"

```bash
# Create missing directory
mkdir -p data/trips
```

### GUI appears blank or frozen

1. Close application
2. Delete cache: `rm -rf __pycache__`
3. Restart application

## 📦 Dependency Details

### CustomTkinter (5.0+)
Modern GUI toolkit with dark theme support
```bash
pip install customtkinter>=5.0.0
```

### NetworkX (2.6+)
Graph algorithms for route planning
```bash
pip install networkx>=2.6
```

### Matplotlib (3.5+)
Data visualization for analytics
```bash
pip install matplotlib>=3.5.0
```

## 🔄 Updating Dependencies

```bash
# Upgrade all packages
pip install --upgrade -r requirements.txt

# Or upgrade specific package
pip install --upgrade customtkinter
```

## 🗂️ Project File Structure

```
ai_trip_planner_v2/
├── main.py                    # Application entry point
├── requirements.txt           # Python dependencies
├── README.md                  # Project documentation
├── SETUP_GUIDE.md            # This file
├── engine/
│   ├── __init__.py
│   ├── models.py             # Data models
│   ├── itinerary_generator.py
│   ├── transport_engine.py
│   ├── ai_insights.py
│   └── trip_manager.py
├── gui/
│   ├── __init__.py
│   └── enhanced_dashboard.py
└── data/
    └── trips/                # Saved trips storage
```

## 🧪 Testing the Installation

After installation, verify everything works:

```bash
# Test 1: Import modules
python -c "import customtkinter; print('CustomTkinter OK')"
python -c "import networkx; print('NetworkX OK')"
python -c "import matplotlib; print('Matplotlib OK')"

# Test 2: Run application
python main.py
```

## 📱 Platform-Specific Notes

### Windows
- Use `python` instead of `python3`
- Use backslashes `\` for paths
- May need to run as Administrator for first-time setup

### macOS
- Use `python3` for Python 3
- May need to install Command Line Tools: `xcode-select --install`
- Use forward slashes `/` for paths

### Linux
- Use `python3` for Python 3
- May need `sudo` for system-wide installations
- Use forward slashes `/` for paths

## 🆘 Getting Help

1. **Check error messages**: Read the terminal output carefully
2. **Check README.md**: Contains troubleshooting section
3. **Check code comments**: Inline documentation in source files
4. **Review data models**: Understand the data structures

## ✅ Verification Checklist

- [ ] Python 3.8+ installed
- [ ] All dependencies installed (`pip list`)
- [ ] Data directory created (`data/trips/`)
- [ ] Application runs without errors
- [ ] GUI window appears
- [ ] Can create a new trip
- [ ] Can save a trip
- [ ] Can view saved trips

## 🎓 Next Steps

1. **Read README.md** for feature overview
2. **Create your first trip** using the application
3. **Explore all tabs** to understand features
4. **Check the code** to understand implementation
5. **Customize** as needed for your use case

## 📞 Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| Module not found | Run `pip install -r requirements.txt` |
| GUI doesn't start | Check Python version, try `python3 main.py` |
| Data not saving | Ensure `data/trips/` directory exists |
| Slow performance | Close other applications, check RAM |
| Port already in use | Change port in configuration |

## 🔐 Security Notes

- Application stores data locally in JSON files
- No data is sent to external servers
- Safe to use with personal travel information
- Back up `data/trips/` folder regularly

## 🎉 You're Ready!

Your AI-Powered Smart Trip Planner is now installed and ready to use.

**Start planning your perfect trip!** ✈️🌍
