"""Algorithms module for graph search and optimization"""

from .search import GraphSearcher, SearchResult

__all__ = ['GraphSearcher', 'SearchResult']
