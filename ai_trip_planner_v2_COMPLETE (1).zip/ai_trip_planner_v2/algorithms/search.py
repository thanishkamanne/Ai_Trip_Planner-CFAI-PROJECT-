"""
Search Algorithms Module
Implements BFS, DFS, UCS, Greedy Best-First Search, and A* Search
"""

import heapq
import time
from typing import List, Dict, Tuple, Optional, Set
from collections import deque
import networkx as nx


class SearchResult:
    """Store search algorithm results"""
    def __init__(self, algorithm_name: str):
        self.algorithm_name = algorithm_name
        self.path = []
        self.cost = 0
        self.explored_nodes = []
        self.execution_time = 0
        self.node_count = 0
        self.edge_count = 0


class GraphSearcher:
    """Implements various graph search algorithms"""
    
    def __init__(self, graph: nx.Graph):
        self.graph = graph
        self.results = {}
    
    def bfs(self, start: str, goal: str) -> SearchResult:
        """Breadth-First Search"""
        result = SearchResult("BFS")
        start_time = time.time()
        
        queue = deque([(start, [start], 0)])
        visited = {start}
        explored = []
        
        while queue:
            node, path, cost = queue.popleft()
            explored.append(node)
            
            if node == goal:
                result.path = path
                result.cost = cost
                result.explored_nodes = explored
                result.execution_time = time.time() - start_time
                result.node_count = len(visited)
                result.edge_count = len(self.graph.edges())
                return result
            
            for neighbor in self.graph.neighbors(node):
                if neighbor not in visited:
                    visited.add(neighbor)
                    edge_cost = self.graph[node][neighbor].get('cost', 1)
                    queue.append((neighbor, path + [neighbor], cost + edge_cost))
        
        result.execution_time = time.time() - start_time
        result.explored_nodes = explored
        result.node_count = len(visited)
        result.edge_count = len(self.graph.edges())
        return result
    
    def dfs(self, start: str, goal: str) -> SearchResult:
        """Depth-First Search"""
        result = SearchResult("DFS")
        start_time = time.time()
        
        stack = [(start, [start], 0)]
        visited = {start}
        explored = []
        
        while stack:
            node, path, cost = stack.pop()
            explored.append(node)
            
            if node == goal:
                result.path = path
                result.cost = cost
                result.explored_nodes = explored
                result.execution_time = time.time() - start_time
                result.node_count = len(visited)
                result.edge_count = len(self.graph.edges())
                return result
            
            for neighbor in sorted(self.graph.neighbors(node), reverse=True):
                if neighbor not in visited:
                    visited.add(neighbor)
                    edge_cost = self.graph[node][neighbor].get('cost', 1)
                    stack.append((neighbor, path + [neighbor], cost + edge_cost))
        
        result.execution_time = time.time() - start_time
        result.explored_nodes = explored
        result.node_count = len(visited)
        result.edge_count = len(self.graph.edges())
        return result
    
    def ucs(self, start: str, goal: str) -> SearchResult:
        """Uniform Cost Search"""
        result = SearchResult("UCS")
        start_time = time.time()
        
        heap = [(0, start, [start])]
        visited = set()
        explored = []
        
        while heap:
            cost, node, path = heapq.heappop(heap)
            
            if node in visited:
                continue
            
            visited.add(node)
            explored.append(node)
            
            if node == goal:
                result.path = path
                result.cost = cost
                result.explored_nodes = explored
                result.execution_time = time.time() - start_time
                result.node_count = len(visited)
                result.edge_count = len(self.graph.edges())
                return result
            
            for neighbor in self.graph.neighbors(node):
                if neighbor not in visited:
                    edge_cost = self.graph[node][neighbor].get('cost', 1)
                    new_cost = cost + edge_cost
                    heapq.heappush(heap, (new_cost, neighbor, path + [neighbor]))
        
        result.execution_time = time.time() - start_time
        result.explored_nodes = explored
        result.node_count = len(visited)
        result.edge_count = len(self.graph.edges())
        return result
    
    def greedy_best_first(self, start: str, goal: str, heuristic: Dict[str, float]) -> SearchResult:
        """Greedy Best-First Search"""
        result = SearchResult("Greedy Best-First")
        start_time = time.time()
        
        heap = [(heuristic.get(start, 0), start, [start], 0)]
        visited = set()
        explored = []
        
        while heap:
            h_val, node, path, cost = heapq.heappop(heap)
            
            if node in visited:
                continue
            
            visited.add(node)
            explored.append(node)
            
            if node == goal:
                result.path = path
                result.cost = cost
                result.explored_nodes = explored
                result.execution_time = time.time() - start_time
                result.node_count = len(visited)
                result.edge_count = len(self.graph.edges())
                return result
            
            for neighbor in self.graph.neighbors(node):
                if neighbor not in visited:
                    edge_cost = self.graph[node][neighbor].get('cost', 1)
                    h_neighbor = heuristic.get(neighbor, 0)
                    heapq.heappush(heap, (h_neighbor, neighbor, path + [neighbor], cost + edge_cost))
        
        result.execution_time = time.time() - start_time
        result.explored_nodes = explored
        result.node_count = len(visited)
        result.edge_count = len(self.graph.edges())
        return result
    
    def a_star(self, start: str, goal: str, heuristic: Dict[str, float]) -> SearchResult:
        """A* Search Algorithm"""
        result = SearchResult("A*")
        start_time = time.time()
        
        g_score = {start: 0}
        f_score = {start: heuristic.get(start, 0)}
        heap = [(f_score[start], start, [start])]
        visited = set()
        explored = []
        
        while heap:
            f_val, node, path = heapq.heappop(heap)
            
            if node in visited:
                continue
            
            visited.add(node)
            explored.append(node)
            
            if node == goal:
                result.path = path
                result.cost = g_score[node]
                result.explored_nodes = explored
                result.execution_time = time.time() - start_time
                result.node_count = len(visited)
                result.edge_count = len(self.graph.edges())
                return result
            
            for neighbor in self.graph.neighbors(node):
                if neighbor not in visited:
                    edge_cost = self.graph[node][neighbor].get('cost', 1)
                    tentative_g = g_score[node] + edge_cost
                    
                    if neighbor not in g_score or tentative_g < g_score[neighbor]:
                        g_score[neighbor] = tentative_g
                        h_neighbor = heuristic.get(neighbor, 0)
                        f_score[neighbor] = tentative_g + h_neighbor
                        heapq.heappush(heap, (f_score[neighbor], neighbor, path + [neighbor]))
        
        result.execution_time = time.time() - start_time
        result.explored_nodes = explored
        result.node_count = len(visited)
        result.edge_count = len(self.graph.edges())
        return result
    
    def compare_algorithms(self, start: str, goal: str, heuristic: Dict[str, float] = None) -> Dict:
        """Compare all algorithms"""
        if heuristic is None:
            heuristic = {node: 0 for node in self.graph.nodes()}
        
        results = {
            'BFS': self.bfs(start, goal),
            'DFS': self.dfs(start, goal),
            'UCS': self.ucs(start, goal),
            'Greedy': self.greedy_best_first(start, goal, heuristic),
            'A*': self.a_star(start, goal, heuristic)
        }
        
        return results
