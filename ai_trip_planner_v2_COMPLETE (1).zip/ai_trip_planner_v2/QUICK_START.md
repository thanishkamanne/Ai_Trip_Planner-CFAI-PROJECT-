# Quick Start Guide - 5 Minutes to Your First Trip Plan

## 🚀 Installation (2 minutes)

### Step 1: Install Python Packages
```bash
cd ai_trip_planner_v2
pip install -r requirements.txt
```

### Step 2: Create Data Directory
```bash
mkdir -p data/trips
```

### Step 3: Run the Application
```bash
python main.py
```

## 🎮 Creating Your First Trip (3 minutes)

### Step 1: Open "New Trip" Tab
- Click on the "✈️ New Trip" tab in the application

### Step 2: Fill in Trip Details
| Field | Example | Notes |
|-------|---------|-------|
| From City | Mumbai | Select from dropdown |
| To City | Delhi | Select from dropdown |
| Start Date | 2026-06-15 | Format: YYYY-MM-DD |
| Duration | 5 | Number of days |
| Budget | 75000 | In rupees (₹) |
| Transport | flight | Options: flight, train, bus, cab |
| Comfort | comfort | Options: budget, standard, comfort, luxury |
| Risk Tolerance | 0.5 | 0 (cautious) to 1 (risk-taker) |
| Interests | sightseeing,food,culture | Comma-separated |

### Step 3: Generate Itinerary
- Click "🚀 Generate Itinerary"
- Wait for generation (takes 2-3 seconds)
- Trip details automatically appear in "Trip Details" tab

## 📋 What You Get

### Complete Day-by-Day Itinerary
- Daily activities and schedule
- Hotel recommendations with prices
- Tourist attractions with ratings
- Meal suggestions
- Daily budget breakdown

### AI Recommendations
- Weather alerts
- Traffic warnings
- Budget insights
- Safety recommendations
- Activity suggestions

### Trip Statistics
- Total cost and budget utilization
- Distance and travel time
- Transport mode details
- Comfort level information

## 💾 Saving Your Trip

1. In "Trip Details" tab, click "💾 Save Trip"
2. Trip is saved with unique ID
3. View all saved trips in "💾 Saved Trips" tab

## 📊 Viewing Analytics

1. Click "📊 Analytics" tab
2. See your travel statistics:
   - Total trips and distance
   - Money spent
   - Favorite cities
   - Carbon footprint

## 🎯 Available Cities

Choose from these 10 Indian cities:
- Mumbai
- Delhi
- Bangalore
- Hyderabad
- Chennai
- Pune
- Jaipur
- Kochi
- Kolkata
- Ahmedabad

## 💡 Pro Tips

1. **Budget Planning**: Set realistic budget (₹30,000-₹2,00,000 for 5 days)
2. **Transport Selection**: 
   - Flight: Fastest but expensive
   - Train: Good balance of time and cost
   - Bus: Most economical
   - Cab: Maximum flexibility
3. **Comfort Levels**:
   - Budget: Basic accommodation and transport
   - Standard: Mid-range options
   - Comfort: Premium but not luxury
   - Luxury: Best available options
4. **Risk Tolerance**: Higher tolerance = more adventurous recommendations
5. **Interests**: More specific interests = better recommendations

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| "No module named customtkinter" | Run `pip install customtkinter` |
| Application won't start | Try `python3 main.py` |
| Data directory error | Run `mkdir -p data/trips` |
| GUI appears blank | Close and restart application |

## 📞 Need Help?

1. Check **README.md** for detailed features
2. Check **SETUP_GUIDE.md** for installation help
3. Check **DOCUMENTATION.md** for technical details

## 🎉 Next Steps

1. ✅ Create your first trip
2. ✅ Save the trip
3. ✅ Create another trip with different preferences
4. ✅ Compare trips in "Saved Trips" tab
5. ✅ Check analytics to see your travel patterns

## 📱 Example Trips to Try

### Trip 1: Budget Adventure
- From: Mumbai → To: Goa
- Duration: 3 days
- Budget: ₹30,000
- Transport: Bus
- Comfort: Budget
- Interests: beaches, food

### Trip 2: Luxury Experience
- From: Delhi → To: Jaipur
- Duration: 4 days
- Budget: ₹1,50,000
- Transport: Flight
- Comfort: Luxury
- Interests: culture, shopping

### Trip 3: Balanced Trip
- From: Bangalore → To: Hyderabad
- Duration: 5 days
- Budget: ₹75,000
- Transport: Train
- Comfort: Standard
- Interests: sightseeing, food, culture

## ✨ Features Highlight

✅ **Complete Itinerary Generation** - Day-by-day plans with activities
✅ **Smart Hotel Recommendations** - Filtered by budget and preferences
✅ **Tourist Attractions** - Curated attractions for each city
✅ **AI Insights** - Weather, traffic, safety, budget recommendations
✅ **Trip Management** - Save, load, and compare trips
✅ **Analytics** - Track your travel patterns
✅ **Modern GUI** - Dark-themed, intuitive interface

---

**Ready to plan your perfect trip?** 🌍✈️

Start by clicking "✈️ New Trip" and follow the steps above!
