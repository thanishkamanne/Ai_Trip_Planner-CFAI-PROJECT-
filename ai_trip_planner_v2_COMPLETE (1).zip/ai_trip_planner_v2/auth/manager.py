"""
Authentication Manager
Handles user login, signup, and session management
"""

import json
import os
import hashlib
from datetime import datetime
from typing import Optional, Dict, Tuple


class AuthManager:
    """Manages user authentication and sessions"""
    
    def __init__(self, users_file: str = "data/users.json"):
        self.users_file = users_file
        self.current_user = None
        self.session_token = None
        self.ensure_users_file()
    
    def ensure_users_file(self):
        """Ensure users file exists"""
        os.makedirs(os.path.dirname(self.users_file), exist_ok=True)
        if not os.path.exists(self.users_file):
            with open(self.users_file, 'w') as f:
                json.dump({}, f)
    
    def hash_password(self, password: str) -> str:
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def load_users(self) -> Dict:
        """Load users from file"""
        try:
            with open(self.users_file, 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def save_users(self, users: Dict):
        """Save users to file"""
        with open(self.users_file, 'w') as f:
            json.dump(users, f, indent=2)
    
    def signup(self, username: str, password: str, email: str) -> Tuple[bool, str]:
        """Create new user account"""
        if not username or not password or not email:
            return False, "All fields are required"
        
        if len(password) < 6:
            return False, "Password must be at least 6 characters"
        
        users = self.load_users()
        
        if username in users:
            return False, "Username already exists"
        
        users[username] = {
            'password': self.hash_password(password),
            'email': email,
            'created_at': datetime.now().isoformat(),
            'trips': []
        }
        
        self.save_users(users)
        return True, "Account created successfully"
    
    def login(self, username: str, password: str) -> Tuple[bool, str]:
        """Authenticate user"""
        if not username or not password:
            return False, "Username and password required"
        
        users = self.load_users()
        
        if username not in users:
            return False, "Invalid username or password"
        
        user = users[username]
        if user['password'] != self.hash_password(password):
            return False, "Invalid username or password"
        
        self.current_user = username
        self.session_token = hashlib.sha256(f"{username}{datetime.now().isoformat()}".encode()).hexdigest()
        return True, "Login successful"
    
    def logout(self):
        """Logout current user"""
        self.current_user = None
        self.session_token = None
    
    def is_logged_in(self) -> bool:
        """Check if user is logged in"""
        return self.current_user is not None
    
    def get_current_user(self) -> Optional[str]:
        """Get current logged-in user"""
        return self.current_user
    
    def get_user_trips(self, username: str) -> list:
        """Get user's saved trips"""
        users = self.load_users()
        if username in users:
            return users[username].get('trips', [])
        return []
    
    def add_user_trip(self, username: str, trip_id: str):
        """Add trip to user's account"""
        users = self.load_users()
        if username in users:
            if trip_id not in users[username]['trips']:
                users[username]['trips'].append(trip_id)
                self.save_users(users)
