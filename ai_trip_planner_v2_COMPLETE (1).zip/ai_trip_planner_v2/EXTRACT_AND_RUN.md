# Extract & Execute - Complete Visual Guide
## AI-Powered Smart Trip Planner V2

---

## 📥 PART 1: EXTRACT THE ZIP FILE

### Method 1: Windows File Manager (Easiest)

#### Step 1.1: Locate the ZIP File

**You should have:**
```
📁 Downloads
├── ai_trip_planner_v2_complete.zip  ← This file
```

**Or wherever you downloaded it:**
- Desktop
- Documents
- Downloads folder

#### Step 1.2: Right-Click the ZIP File

**Screenshot:**
```
📁 Downloads
│
├── 📦 ai_trip_planner_v2_complete.zip
│   ↓ Right-click here
│
└── Context Menu Appears:
    ├── Open
    ├── Open with
    ├── Send to
    ├── Cut
    ├── Copy
    ├── Delete
    ├── Rename
    ├── Properties
    └── Extract All...  ← CLICK THIS
```

#### Step 1.3: Click "Extract All..."

**Window Opens:**
```
┌─────────────────────────────────────────────────────────┐
│ Extract Compressed (Zipped) Folder                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Select a destination and press Extract to unzip the    │
│ file(s).                                               │
│                                                         │
│ Destination: C:\Users\YourName\Downloads              │
│              [Browse...]                               │
│                                                         │
│ ☑ Show extracted files when complete                   │
│                                                         │
│ [Cancel]  [Extract]                                    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

#### Step 1.4: Choose Destination (Optional)

**Default is fine:**
- Downloads folder
- Desktop
- Documents

**Or click "Browse..." to choose custom location**

#### Step 1.5: Click "Extract"

**Extraction starts...**
```
┌─────────────────────────────────────────────────────────┐
│ Extracting...                                           │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Extracting ai_trip_planner_v2_complete.zip             │
│                                                         │
│ ████████████████████████░░░░░░░░░░ 65%                │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Wait for completion...**

#### Step 1.6: Extraction Complete

**New folder appears:**
```
📁 Downloads
├── 📦 ai_trip_planner_v2_complete.zip  (original)
└── 📁 ai_trip_planner_v2/               (extracted) ← NEW!
    ├── main.py
    ├── requirements.txt
    ├── engine/
    ├── gui/
    ├── data/
    └── [other files]
```

✅ **Extraction successful!**

---

### Method 2: macOS (Finder)

#### Step 2.1: Locate ZIP File

**In Finder:**
```
📁 Downloads
└── 📦 ai_trip_planner_v2_complete.zip
```

#### Step 2.2: Double-Click the ZIP

**Just double-click it!**

**Automatically extracts to:**
```
📁 Downloads
├── 📦 ai_trip_planner_v2_complete.zip
└── 📁 ai_trip_planner_v2/  ← Extracted!
```

✅ **Done!**

---

### Method 3: Linux Terminal

#### Step 3.1: Open Terminal

**Press:** `Ctrl + Alt + T`

#### Step 3.2: Navigate to Download Folder

```bash
cd Downloads
```

#### Step 3.3: Extract ZIP

```bash
unzip ai_trip_planner_v2_complete.zip
```

**Output:**
```
Archive:  ai_trip_planner_v2_complete.zip
  inflating: ai_trip_planner_v2/main.py
  inflating: ai_trip_planner_v2/requirements.txt
  inflating: ai_trip_planner_v2/engine/models.py
  ...
```

#### Step 3.4: Verify Extraction

```bash
ls -la ai_trip_planner_v2/
```

**Output:**
```
total 120
drwxr-xr-x  8 user user  4096 Jun  7 14:38 .
drwxr-xr-x 15 user user  4096 Jun  7 15:00 ..
-rw-r--r--  1 user user  2048 Jun  7 14:38 main.py
-rw-r--r--  1 user user   156 Jun  7 14:38 requirements.txt
drwxr-xr-x  2 user user  4096 Jun  7 14:38 engine
drwxr-xr-x  2 user user  4096 Jun  7 14:38 gui
drwxr-xr-x  2 user user  4096 Jun  7 14:38 data
```

✅ **Extracted successfully!**

---

## 🚀 PART 2: EXECUTE THE APPLICATION

### Step 1: Open Command Prompt / Terminal

#### Windows:
1. Press `Win + R`
2. Type: `cmd`
3. Press Enter

**Command Prompt opens:**
```
C:\Users\YourName>
```

#### macOS:
1. Press `Cmd + Space`
2. Type: `terminal`
3. Press Enter

**Terminal opens:**
```
user@MacBook ~ %
```

#### Linux:
1. Press `Ctrl + Alt + T`

**Terminal opens:**
```
user@computer:~$
```

---

### Step 2: Navigate to Project Folder

#### Windows:
```bash
cd Downloads\ai_trip_planner_v2
```

**Or if extracted to Desktop:**
```bash
cd Desktop\ai_trip_planner_v2
```

**Or if extracted to Documents:**
```bash
cd Documents\ai_trip_planner_v2
```

**Result:**
```
C:\Users\YourName\Downloads\ai_trip_planner_v2>
```

#### macOS/Linux:
```bash
cd Downloads/ai_trip_planner_v2
```

**Or:**
```bash
cd Desktop/ai_trip_planner_v2
```

**Result:**
```
user@MacBook ai_trip_planner_v2 %
```

---

### Step 3: Verify You're in Correct Folder

**Type this command:**

**Windows:**
```bash
dir
```

**macOS/Linux:**
```bash
ls
```

**You should see:**
```
main.py
requirements.txt
README.md
engine/
gui/
data/
QUICK_START.md
SETUP_GUIDE.md
PYCHARM_SETUP_VISUAL.md
EXECUTION_GUIDE.md
```

✅ **You're in the right folder!**

---

### Step 4: Install Dependencies

**Type this command:**
```bash
pip install -r requirements.txt
```

**Installation starts:**
```
Collecting customtkinter
  Downloading customtkinter-5.2.0-py3-none-win_amd64.whl
  
Collecting networkx
  Downloading networkx-3.2.1-py3-none-any.whl
  
Collecting matplotlib
  Downloading matplotlib-3.8.2-py3-none-any.whl

Installing collected packages: customtkinter, networkx, matplotlib
Successfully installed customtkinter-5.2.0
Successfully installed networkx-3.2.1
Successfully installed matplotlib-3.8.2
```

**Wait for completion...**

✅ **Dependencies installed!**

---

### Step 5: Create Data Directory

**Windows:**
```bash
mkdir data\trips
```

**macOS/Linux:**
```bash
mkdir -p data/trips
```

**No output = success!**

✅ **Data directory created!**

---

### Step 6: Run the Application

**Type this command:**

**Windows:**
```bash
python main.py
```

**macOS/Linux:**
```bash
python3 main.py
```

**Terminal shows:**
```
Starting AI-Powered Smart Trip Planner...
GUI initialized successfully
Waiting for user input...
```

**And a new window appears:**

```
┌─────────────────────────────────────────────────────────┐
│ AI-Powered Smart Trip Planner                  _ □ X  │
├─────────────────────────────────────────────────────────┤
│ [Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics] │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  🏠 DASHBOARD                                          │
│  ═══════════════════════════════════════════════════   │
│                                                         │
│  📊 QUICK STATS                                        │
│  ┌─────────────┬─────────────┬─────────────┐          │
│  │ 📊 Trips: 0 │ 📍 Cities: 0 │ 💰 Spent: ₹0 │         │
│  └─────────────┴─────────────┴─────────────┘          │
│                                                         │
│  [✈️ New Trip] [📂 Load] [📊 Compare] [⚙️ Settings]   │
│                                                         │
│  📅 UPCOMING TRIPS                                     │
│  (No trips yet)                                        │
│                                                         │
│  💡 AI RECOMMENDATIONS                                 │
│  • Great weather expected in Bangalore next week       │
│  • Flight prices dropping for Mumbai-Delhi route       │
│  • New luxury hotels opened in Hyderabad               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

✅ **Application is running!**

---

## 🎮 PART 3: USE THE APPLICATION

### Step 1: Click "New Trip" Tab

**In the application window:**
```
[Dashboard] [✈️ New Trip] [📋 Details] [💾 Saved] [📊 Analytics]
             ↑ CLICK HERE
```

**Form appears:**
```
┌─────────────────────────────────────────────────────────┐
│ ✈️ Plan Your Perfect Trip                              │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ From City:        [Mumbai          ▼]                 │
│ To City:          [Delhi           ▼]                 │
│ Start Date:       [2026-06-15     ]                   │
│ Duration:         [5              ]                   │
│ Budget:           [75000          ]                   │
│ Transport Mode:   [flight         ▼]                 │
│ Comfort Level:    [comfort        ▼]                 │
│ Risk Tolerance:   [0.5            ]                   │
│ Interests:        [sightseeing,food,culture]          │
│                                                         │
│ [🚀 Generate Itinerary]                               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Step 2: Fill in the Form

**Click each field and enter:**

1. **From City:** Click dropdown → Select **Mumbai**
2. **To City:** Click dropdown → Select **Delhi**
3. **Start Date:** Click field → Type **2026-06-15**
4. **Duration:** Click field → Type **5**
5. **Budget:** Click field → Type **75000**
6. **Transport Mode:** Click dropdown → Select **flight**
7. **Comfort Level:** Click dropdown → Select **comfort**
8. **Risk Tolerance:** Click field → Type **0.5**
9. **Interests:** Click field → Type **sightseeing,food,culture**

### Step 3: Generate Itinerary

**Click the button:**
```
[🚀 Generate Itinerary]
```

**Wait 2-3 seconds...**

**Success message:**
```
┌─────────────────────────────────────────────────────────┐
│ ✅ Itinerary generated successfully!                   │
│                                                         │
│ [OK]                                                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Step 4: View Trip Details

**Automatically shows:**
```
┌─────────────────────────────────────────────────────────┐
│ 📋 Trip Details                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ ✈️ TRIP ITINERARY: Mumbai → Delhi                     │
│ Duration: 5 days (2026-06-15 to 2026-06-19)          │
│ Budget: ₹75,000 | Total Cost: ₹72,000                │
│                                                         │
│ 📍 DAY 1 - Mumbai                                      │
│ Activities: Sightseeing, Gateway of India             │
│ 🏨 Hotels: 3 options (₹8000-12000/night)              │
│ 🎫 Attractions: Gateway, Marine Drive, Taj Mahal      │
│ 🍽️ Meals: Vada Pav, Pav Bhaji, Seafood               │
│ 💰 Daily Budget: ₹15,000                              │
│                                                         │
│ [... Days 2-5 ...]                                     │
│                                                         │
│ 💡 AI RECOMMENDATIONS                                  │
│ • ✈️ Flight recommended for faster travel              │
│ • 🌤️ Check weather forecast                            │
│ • 🎫 Book attractions in advance                       │
│                                                         │
│ [💾 Save Trip] [📄 Export PDF] [📤 Share]            │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Step 5: Save Your Trip

**Click:**
```
[💾 Save Trip]
```

**Success:**
```
✅ Trip saved successfully!
Trip ID: trip_20260607_143825
```

### Step 6: View Saved Trips

**Click tab:**
```
[💾 Saved Trips]
```

**You see:**
```
📍 Mumbai → Delhi
📅 2026-06-15 to 2026-06-19 (5 days)
💰 ₹72,000 / ₹75,000
✈️ FLIGHT
ID: trip_20260607_143825
```

### Step 7: View Analytics

**Click tab:**
```
[📊 Analytics]
```

**You see:**
```
📊 TRAVEL STATISTICS

📊 Total Trips: 1
📍 Total Distance: 1400 km
💰 Total Spent: ₹72,000
⏱️ Average Trip Duration: 5.0 days

🏙️ Favorite Cities: Delhi, Mumbai
✈️ Favorite Transport: flight
🌍 Most Visited: Delhi
🌱 Carbon Footprint: 210 kg CO2
```

---

## 📋 COMPLETE WORKFLOW SUMMARY

```
1. Download ZIP file
   ↓
2. Right-click → Extract All
   ↓
3. Open Command Prompt / Terminal
   ↓
4. cd Downloads\ai_trip_planner_v2
   ↓
5. pip install -r requirements.txt
   ↓
6. mkdir -p data/trips
   ↓
7. python main.py
   ↓
8. Click "New Trip" tab
   ↓
9. Fill form and click "Generate Itinerary"
   ↓
10. View trip details
    ↓
11. Click "Save Trip"
    ↓
12. View "Saved Trips" or "Analytics"
```

---

## ⏱️ TIMING

| Step | Time |
|------|------|
| Extract ZIP | 1 min |
| Install dependencies | 3-5 min |
| Create data folder | 30 sec |
| Run application | 30 sec |
| Create trip | 3-5 min |
| View results | 1 min |
| Save trip | 30 sec |
| **Total** | **10-15 min** |

---

## 🆘 TROUBLESHOOTING

### Problem: "Python not found"

**Solution:**
1. Download Python 3.14 from python.org
2. Install it (check "Add Python to PATH")
3. Restart Command Prompt
4. Try again

### Problem: "No module named 'customtkinter'"

**Solution:**
```bash
pip install customtkinter
```

### Problem: Application won't start

**Solution:**
```bash
python3 main.py
```

(Try with `python3` instead of `python`)

### Problem: GUI appears blank

**Solution:**
1. Close application
2. Delete cache: `rm -rf __pycache__`
3. Run again

### Problem: "Cannot find data directory"

**Solution:**
```bash
mkdir -p data/trips
```

---

## 🎉 YOU'RE DONE!

You now have a fully functional AI-Powered Smart Trip Planner running on your system!

**Next steps:**
1. Create multiple trips
2. Compare different routes
3. Explore all features
4. Customize for your needs

---

**Happy Trip Planning!** ✈️🌍
