# Step-by-Step Execution Guide
## AI-Powered Smart Trip Planner

---

## 🎯 PHASE 1: SYSTEM SETUP (5-10 minutes)

### Step 1.1: Check Python Installation

**Windows:**
```bash
python --version
```

**macOS/Linux:**
```bash
python3 --version
```

**Expected Output:**
```
Python 3.8.0 (or higher)
```

**If Python is not installed:**
- Download from https://www.python.org/downloads/
- Install with "Add Python to PATH" checked (Windows)
- Restart your computer

---

### Step 1.2: Extract the Project

**Option A: Using File Manager**
1. Right-click `ai_trip_planner_v2_complete.zip`
2. Select "Extract All" (Windows) or "Extract" (macOS/Linux)
3. Choose destination folder

**Option B: Using Command Line**

**Windows (PowerShell):**
```powershell
Expand-Archive -Path ai_trip_planner_v2_complete.zip -DestinationPath .
```

**macOS/Linux:**
```bash
unzip ai_trip_planner_v2_complete.zip
```

**Expected Result:**
```
ai_trip_planner_v2/
├── main.py
├── requirements.txt
├── engine/
├── gui/
└── data/
```

---

### Step 1.3: Navigate to Project Directory

**Windows (Command Prompt):**
```bash
cd ai_trip_planner_v2
```

**Windows (PowerShell):**
```powershell
cd ai_trip_planner_v2
```

**macOS/Linux (Terminal):**
```bash
cd ai_trip_planner_v2
```

**Verify you're in correct directory:**
```bash
dir          # Windows
ls           # macOS/Linux
```

**Expected Output:**
```
main.py
requirements.txt
README.md
SETUP_GUIDE.md
engine/
gui/
data/
```

---

### Step 1.4: Create Virtual Environment (Optional but Recommended)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**Expected Output:**
```
(venv) C:\path\to\ai_trip_planner_v2>    # Windows
(venv) user@machine:~/ai_trip_planner_v2$  # macOS/Linux
```

---

### Step 1.5: Install Dependencies

**All Platforms:**
```bash
pip install -r requirements.txt
```

**Or install individually:**
```bash
pip install customtkinter
pip install networkx
pip install matplotlib
```

**Wait for installation to complete...**

**Expected Output:**
```
Successfully installed customtkinter-5.x.x
Successfully installed networkx-2.x.x
Successfully installed matplotlib-3.x.x
```

**Verify Installation:**
```bash
pip list
```

**Should show:**
```
customtkinter      5.x.x
networkx           2.x.x
matplotlib         3.x.x
```

---

### Step 1.6: Create Data Directory

**Windows:**
```bash
mkdir data\trips
```

**macOS/Linux:**
```bash
mkdir -p data/trips
```

**Verify:**
```bash
dir data          # Windows
ls data           # macOS/Linux
```

---

## 🎮 PHASE 2: RUNNING THE APPLICATION (1 minute)

### Step 2.1: Start the Application

**Windows:**
```bash
python main.py
```

**macOS/Linux:**
```bash
python3 main.py
```

**Expected Output in Terminal:**
```
Starting AI-Powered Smart Trip Planner...
GUI initialized successfully
Waiting for user input...
```

**Application Window Should Appear:**
- Dark-themed window with title "AI-Powered Smart Trip Planner"
- Size: 1400x900 pixels
- 5 tabs visible at top

---

### Step 2.2: Verify Application Loaded

**Check for:**
- ✅ Main window appears
- ✅ Dark theme applied
- ✅ 5 tabs visible: Dashboard, New Trip, Trip Details, Saved Trips, Analytics
- ✅ No error messages in terminal

**If Application Doesn't Start:**
- Check terminal for error messages
- Verify all dependencies installed: `pip list`
- Try: `python3 main.py` (if using `python` didn't work)
- Check Python version: `python --version`

---

## 📝 PHASE 3: CREATING YOUR FIRST TRIP (3-5 minutes)

### Step 3.1: Click "New Trip" Tab

**In the Application Window:**
1. Look at the tab bar at the top
2. Click on "✈️ New Trip" tab
3. You should see a form with input fields

---

### Step 3.2: Fill in Trip Details

**Form Fields to Fill:**

#### 1. From City
```
Click dropdown → Select "Mumbai"
```

#### 2. To City
```
Click dropdown → Select "Delhi"
```

#### 3. Start Date
```
Click field → Enter: 2026-06-15
Format: YYYY-MM-DD
```

#### 4. Duration (days)
```
Click field → Enter: 5
```

#### 5. Budget (₹)
```
Click field → Enter: 75000
```

#### 6. Transport Mode
```
Click dropdown → Select: flight
Options: flight, train, bus, cab
```

#### 7. Comfort Level
```
Click dropdown → Select: comfort
Options: budget, standard, comfort, luxury
```

#### 8. Risk Tolerance (0-1)
```
Click field → Enter: 0.5
Range: 0 (very cautious) to 1 (risk-taker)
```

#### 9. Interests
```
Click field → Enter: sightseeing,food,culture
Separate with commas
```

**Completed Form Should Look Like:**
```
From City:           Mumbai
To City:             Delhi
Start Date:          2026-06-15
Duration:            5
Budget:              75000
Transport Mode:      flight
Comfort Level:       comfort
Risk Tolerance:      0.5
Interests:           sightseeing,food,culture
```

---

### Step 3.3: Generate Itinerary

**Click the Button:**
1. Look for "🚀 Generate Itinerary" button (cyan/blue color)
2. Click it
3. Wait 2-3 seconds for processing

**Expected Output:**
- Information dialog: "Generating your perfect itinerary..."
- Processing happens in background
- Automatically switches to "Trip Details" tab
- Success message appears

---

## 📋 PHASE 4: VIEWING TRIP DETAILS (2 minutes)

### Step 4.1: View Generated Itinerary

**You Should See:**
1. Trip Overview section with:
   - Trip ID
   - Duration (5 days)
   - Budget and Total Cost
   - Distance and Transport Mode

2. Day-by-Day Itinerary:
   - **Day 1 - Mumbai**
     - Activities list
     - Hotel recommendations with prices
     - Attractions with ratings
     - Meal suggestions
     - Daily budget

   - **Day 2 - Transit to Delhi**
     - Flight details
     - Travel time and cost

   - **Days 3-5 - Delhi**
     - Activities and attractions
     - Hotels and meals
     - Daily budgets

3. AI Recommendations section:
   - Weather alerts
   - Traffic warnings
   - Budget insights
   - Safety recommendations

---

### Step 4.2: Scroll Through Details

**Use the Scrollbar:**
1. On the right side of the text area, there's a scrollbar
2. Drag down to see more details
3. Read through all recommendations

---

## 💾 PHASE 5: SAVING YOUR TRIP (1 minute)

### Step 5.1: Click Save Trip Button

**In Trip Details Tab:**
1. Look for "💾 Save Trip" button (bottom left)
2. Click it

**Expected Output:**
- Success dialog appears
- Shows Trip ID (unique identifier)
- Message: "Trip saved successfully!"

**Example:**
```
Trip saved successfully!
Trip ID: trip_20260607_143825
```

---

### Step 5.2: Verify Trip Saved

**Check Saved Trips Tab:**
1. Click on "💾 Saved Trips" tab
2. You should see your trip listed with:
   - Source and destination
   - Dates
   - Budget and cost
   - Transport mode
   - Trip ID

---

## 📊 PHASE 6: VIEWING ANALYTICS (1 minute)

### Step 6.1: Click Analytics Tab

**In the Application:**
1. Click on "📊 Analytics" tab
2. You should see statistics

---

### Step 6.2: View Your Statistics

**You Should See:**
```
TRAVEL STATISTICS
==================================================

📊 Total Trips: 1
📍 Total Distance: 1400 km
💰 Total Spent: ₹72,000
⏱️ Average Trip Duration: 5.0 days

🏙️ Favorite Cities: Delhi, Mumbai
✈️ Favorite Transport: flight
🌍 Most Visited: Delhi
🌱 Carbon Footprint: 210 kg CO2
```

---

## 🎯 PHASE 7: CREATE ADDITIONAL TRIPS (Optional)

### Step 7.1: Create Trip 2

**Go back to "New Trip" tab:**
```
From City:           Bangalore
To City:             Chennai
Start Date:          2026-07-01
Duration:            3
Budget:              50000
Transport Mode:      train
Comfort Level:       standard
Risk Tolerance:      0.5
Interests:           beaches,food
```

**Click "Generate Itinerary"**

---

### Step 7.2: Compare Trips

**Go to "Saved Trips" tab:**
1. You should see 2 trips listed
2. Compare:
   - Cost differences
   - Duration differences
   - Transport modes
   - Budget utilization

---

## 🔄 PHASE 8: TROUBLESHOOTING

### Issue: "No module named 'customtkinter'"

**Solution:**
```bash
pip install customtkinter
```

**Then restart:**
```bash
python main.py
```

---

### Issue: Application window doesn't appear

**Solution 1: Try with python3**
```bash
python3 main.py
```

**Solution 2: Check Python version**
```bash
python --version
# Should be 3.8 or higher
```

**Solution 3: Reinstall dependencies**
```bash
pip install -r requirements.txt --force-reinstall
```

---

### Issue: "Cannot find data directory"

**Solution:**
```bash
mkdir -p data/trips
```

**Then restart:**
```bash
python main.py
```

---

### Issue: GUI appears blank

**Solution:**
1. Close the application (Alt+F4 or Cmd+Q)
2. Delete cache:
   ```bash
   rm -rf __pycache__
   ```
3. Restart:
   ```bash
   python main.py
   ```

---

### Issue: Application is very slow

**Solution:**
1. Close other applications
2. Check available RAM
3. Try restarting the application

---

## 📱 COMPLETE WORKFLOW SUMMARY

```
1. Extract ZIP file
   ↓
2. Open Terminal/Command Prompt
   ↓
3. Navigate to ai_trip_planner_v2 folder
   ↓
4. Install dependencies: pip install -r requirements.txt
   ↓
5. Create data directory: mkdir -p data/trips
   ↓
6. Run application: python main.py
   ↓
7. Click "New Trip" tab
   ↓
8. Fill in trip details
   ↓
9. Click "Generate Itinerary"
   ↓
10. View trip details
    ↓
11. Click "Save Trip"
    ↓
12. View "Saved Trips" or "Analytics"
```

---

## ⏱️ TIMING BREAKDOWN

| Phase | Time | Task |
|-------|------|------|
| 1 | 5-10 min | Setup (Python, extract, install) |
| 2 | 1 min | Start application |
| 3 | 3-5 min | Create trip |
| 4 | 2 min | View details |
| 5 | 1 min | Save trip |
| 6 | 1 min | View analytics |
| **Total** | **13-20 min** | **Complete workflow** |

---

## 🎓 EXAMPLE TRIP SCENARIOS

### Scenario 1: Budget Beach Trip
```
From City:           Mumbai
To City:             Goa
Start Date:          2026-07-15
Duration:            3
Budget:              30000
Transport Mode:      bus
Comfort Level:       budget
Risk Tolerance:      0.7
Interests:           beaches,food,nightlife
```

### Scenario 2: Luxury City Tour
```
From City:           Delhi
To City:             Jaipur
Start Date:          2026-08-01
Duration:            4
Budget:              150000
Transport Mode:      flight
Comfort Level:       luxury
Risk Tolerance:      0.3
Interests:           culture,shopping,heritage
```

### Scenario 3: Balanced Adventure
```
From City:           Bangalore
To City:             Hyderabad
Start Date:          2026-08-15
Duration:            5
Budget:              75000
Transport Mode:      train
Comfort Level:       standard
Risk Tolerance:      0.5
Interests:           sightseeing,food,culture
```

---

## ✅ VERIFICATION CHECKLIST

After completing all phases, verify:

- [ ] Python 3.8+ installed
- [ ] Project extracted successfully
- [ ] All dependencies installed
- [ ] Data directory created
- [ ] Application starts without errors
- [ ] GUI window appears with 5 tabs
- [ ] Can fill and submit trip form
- [ ] Itinerary generates successfully
- [ ] Trip details display correctly
- [ ] Trip saves successfully
- [ ] Saved trips appear in list
- [ ] Analytics shows statistics

---

## 🆘 QUICK HELP

**Can't start application?**
```bash
# Check Python
python --version

# Reinstall dependencies
pip install -r requirements.txt

# Try with python3
python3 main.py
```

**Need to reset?**
```bash
# Delete all saved trips
rm -rf data/trips/*

# Delete cache
rm -rf __pycache__

# Restart
python main.py
```

---

## 🎉 YOU'RE READY!

Follow the steps above and you'll have a fully functional AI-Powered Smart Trip Planner running on your system!

**Questions?** Check the README.md, SETUP_GUIDE.md, or DOCUMENTATION.md files.

**Happy trip planning!** ✈️🌍
