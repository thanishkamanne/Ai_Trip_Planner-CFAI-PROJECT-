"""
Utility Helper Functions
"""

import math
from datetime import datetime, timedelta
from typing import Tuple, List, Dict


def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between two coordinates using Haversine formula"""
    R = 6371  # Earth's radius in km
    
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)
    
    a = math.sin(delta_lat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    return R * c


def format_currency(amount: float) -> str:
    """Format amount as Indian currency"""
    return f"₹{amount:,.0f}"


def format_date(date_obj: datetime) -> str:
    """Format date as string"""
    return date_obj.strftime("%Y-%m-%d")


def parse_date(date_str: str) -> datetime:
    """Parse date string to datetime"""
    return datetime.strptime(date_str, "%Y-%m-%d")


def calculate_trip_duration(start_date: datetime, end_date: datetime) -> int:
    """Calculate trip duration in days"""
    return (end_date - start_date).days + 1


def get_date_range(start_date: datetime, days: int) -> List[datetime]:
    """Get list of dates for trip"""
    return [start_date + timedelta(days=i) for i in range(days)]


def calculate_daily_budget(total_budget: float, days: int) -> float:
    """Calculate daily budget"""
    return total_budget / days


def estimate_travel_time(distance: float, speed: float = 60) -> float:
    """Estimate travel time in hours"""
    return distance / speed


def get_time_of_day(hour: int) -> str:
    """Get time of day description"""
    if 5 <= hour < 12:
        return "Morning"
    elif 12 <= hour < 17:
        return "Afternoon"
    elif 17 <= hour < 21:
        return "Evening"
    else:
        return "Night"


def validate_email(email: str) -> bool:
    """Validate email format"""
    return "@" in email and "." in email.split("@")[1]


def validate_budget(budget: float) -> bool:
    """Validate budget is positive"""
    return budget > 0


def validate_duration(duration: int) -> bool:
    """Validate trip duration"""
    return 1 <= duration <= 365


def get_weather_description(weather_code: int) -> str:
    """Get weather description from code"""
    weather_map = {
        0: "Clear Sky",
        1: "Partly Cloudy",
        2: "Cloudy",
        3: "Rainy",
        4: "Heavy Rain",
        5: "Thunderstorm",
        6: "Snow",
        7: "Fog"
    }
    return weather_map.get(weather_code, "Unknown")


def get_risk_level(risk_tolerance: float) -> str:
    """Get risk level description"""
    if risk_tolerance < 0.3:
        return "Low Risk"
    elif risk_tolerance < 0.6:
        return "Moderate Risk"
    elif risk_tolerance < 0.8:
        return "High Risk"
    else:
        return "Very High Risk"


def calculate_carbon_footprint(distance: float, transport_mode: str) -> float:
    """Calculate carbon footprint in kg CO2"""
    # Approximate emissions per km
    emissions = {
        'flight': 0.255,
        'train': 0.041,
        'bus': 0.089,
        'cab': 0.192
    }
    
    return distance * emissions.get(transport_mode, 0.1)


def format_time_duration(hours: float) -> str:
    """Format time duration"""
    h = int(hours)
    m = int((hours - h) * 60)
    return f"{h}h {m}m"


def round_to_nearest(value: float, nearest: int = 100) -> float:
    """Round to nearest value"""
    return round(value / nearest) * nearest
