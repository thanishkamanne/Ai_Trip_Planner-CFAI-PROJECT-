"""
AI-Powered Smart Trip Planner - Enhanced Version
Complete travel planning application with itinerary generation, transport options, 
hotel recommendations, attractions, and AI-powered insights
"""

import customtkinter as ctk
from tkinter import messagebox, ttk
from datetime import datetime, timedelta
import os
import sys

# Add project to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine.models import (
    TripItinerary, TransportMode, ComfortLevel, TravelStatistics
)
from engine.itinerary_generator import ItineraryGenerator
from engine.transport_engine import TransportEngine
from engine.ai_insights import AIInsightsEngine
from engine.trip_manager import TripManager
from gui.enhanced_dashboard import EnhancedDashboard, TripPlannerWindow


class SmartTripPlannerApp(ctk.CTk):
    """Main application class"""
    
    def __init__(self):
        super().__init__()
        
        # Initialize engines
        self.itinerary_gen = ItineraryGenerator()
        self.transport_engine = TransportEngine()
        self.insights_engine = AIInsightsEngine()
        self.trip_manager = TripManager()
        
        # Current trip
        self.current_trip: Optional[TripItinerary] = None
        
        # Setup window
        self.title("AI-Powered Smart Trip Planner")
        self.geometry("1400x900")
        
        # Configure theme
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        
        # Setup UI
        self.setup_ui()
        
        # Center window
        self.center_window()
    
    def center_window(self):
        """Center window on screen"""
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
    
    def setup_ui(self):
        """Setup main UI"""
        # Configure grid
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self)
        self.notebook.grid(row=0, column=0, sticky="nsew")
        
        # Dashboard tab
        self.dashboard_frame = ctk.CTkFrame(self.notebook, fg_color="#0a0a0a")
        self.notebook.add(self.dashboard_frame, text="🏠 Dashboard")
        self.setup_dashboard_tab()
        
        # Trip Planner tab
        self.planner_frame = ctk.CTkFrame(self.notebook, fg_color="#0a0a0a")
        self.notebook.add(self.planner_frame, text="✈️ New Trip")
        self.setup_planner_tab()
        
        # Trip Details tab
        self.details_frame = ctk.CTkFrame(self.notebook, fg_color="#0a0a0a")
        self.notebook.add(self.details_frame, text="📋 Trip Details")
        self.setup_details_tab()
        
        # Saved Trips tab
        self.saved_frame = ctk.CTkFrame(self.notebook, fg_color="#0a0a0a")
        self.notebook.add(self.saved_frame, text="💾 Saved Trips")
        self.setup_saved_trips_tab()
        
        # Analytics tab
        self.analytics_frame = ctk.CTkFrame(self.notebook, fg_color="#0a0a0a")
        self.notebook.add(self.analytics_frame, text="📊 Analytics")
        self.setup_analytics_tab()
    
    def setup_dashboard_tab(self):
        """Setup dashboard tab"""
        self.dashboard_frame.grid_rowconfigure(0, weight=1)
        self.dashboard_frame.grid_columnconfigure(0, weight=1)
        
        dashboard = EnhancedDashboard(
            self.dashboard_frame,
            on_new_trip=lambda: self.notebook.select(1),
            on_load_trip=self.load_trip_dialog,
            on_view_trip=lambda: self.notebook.select(2)
        )
        dashboard.grid(row=0, column=0, sticky="nsew")
    
    def setup_planner_tab(self):
        """Setup trip planner tab"""
        self.planner_frame.grid_rowconfigure(0, weight=1)
        self.planner_frame.grid_columnconfigure(0, weight=1)
        
        # Create scrollable frame
        scroll_frame = ctk.CTkScrollableFrame(self.planner_frame, fg_color="transparent")
        scroll_frame.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        scroll_frame.grid_columnconfigure(0, weight=1)
        
        # Title
        title_label = ctk.CTkLabel(
            scroll_frame,
            text="✈️ Plan Your Perfect Trip",
            font=("Helvetica", 24, "bold"),
            text_color="#00d9ff"
        )
        title_label.grid(row=0, column=0, sticky="w", pady=(0, 20))
        
        # Input fields
        row = 1
        
        # Source city
        ctk.CTkLabel(scroll_frame, text="From City:", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.source_var = ctk.StringVar(value="Mumbai")
        source_combo = ctk.CTkComboBox(
            scroll_frame,
            values=["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Pune", "Jaipur", "Kochi", "Kolkata", "Ahmedabad"],
            variable=self.source_var
        )
        source_combo.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Destination city
        ctk.CTkLabel(scroll_frame, text="To City:", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.dest_var = ctk.StringVar(value="Delhi")
        dest_combo = ctk.CTkComboBox(
            scroll_frame,
            values=["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Pune", "Jaipur", "Kochi", "Kolkata", "Ahmedabad"],
            variable=self.dest_var
        )
        dest_combo.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Start date
        ctk.CTkLabel(scroll_frame, text="Start Date (YYYY-MM-DD):", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.start_date_var = ctk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        start_date_entry = ctk.CTkEntry(scroll_frame, textvariable=self.start_date_var)
        start_date_entry.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Duration
        ctk.CTkLabel(scroll_frame, text="Duration (days):", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.duration_var = ctk.StringVar(value="5")
        duration_entry = ctk.CTkEntry(scroll_frame, textvariable=self.duration_var)
        duration_entry.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Budget
        ctk.CTkLabel(scroll_frame, text="Budget (₹):", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.budget_var = ctk.StringVar(value="50000")
        budget_entry = ctk.CTkEntry(scroll_frame, textvariable=self.budget_var)
        budget_entry.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Transport preference
        ctk.CTkLabel(scroll_frame, text="Transport Mode:", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.transport_var = ctk.StringVar(value="flight")
        transport_combo = ctk.CTkComboBox(
            scroll_frame,
            values=["flight", "train", "bus", "cab"],
            variable=self.transport_var
        )
        transport_combo.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Comfort preference
        ctk.CTkLabel(scroll_frame, text="Comfort Level:", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.comfort_var = ctk.StringVar(value="standard")
        comfort_combo = ctk.CTkComboBox(
            scroll_frame,
            values=["budget", "standard", "comfort", "luxury"],
            variable=self.comfort_var
        )
        comfort_combo.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Risk tolerance
        ctk.CTkLabel(scroll_frame, text="Risk Tolerance (0-1):", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.risk_var = ctk.StringVar(value="0.5")
        risk_entry = ctk.CTkEntry(scroll_frame, textvariable=self.risk_var)
        risk_entry.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Interests
        ctk.CTkLabel(scroll_frame, text="Interests (comma-separated):", font=("Helvetica", 12)).grid(row=row, column=0, sticky="w")
        self.interests_var = ctk.StringVar(value="sightseeing,food,culture")
        interests_entry = ctk.CTkEntry(scroll_frame, textvariable=self.interests_var)
        interests_entry.grid(row=row, column=1, sticky="ew", pady=10)
        row += 1
        
        # Generate button
        generate_btn = ctk.CTkButton(
            scroll_frame,
            text="🚀 Generate Itinerary",
            font=("Helvetica", 14, "bold"),
            fg_color="#00d9ff",
            text_color="#0a1628",
            height=45,
            command=self.generate_itinerary
        )
        generate_btn.grid(row=row, column=0, columnspan=2, sticky="ew", pady=(20, 0))
        
        scroll_frame.grid_columnconfigure(1, weight=1)
    
    def setup_details_tab(self):
        """Setup trip details tab"""
        self.details_frame.grid_rowconfigure(0, weight=1)
        self.details_frame.grid_columnconfigure(0, weight=1)
        
        self.details_text = ctk.CTkTextbox(self.details_frame, fg_color="#1a1a1a")
        self.details_text.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        
        # Buttons frame
        btn_frame = ctk.CTkFrame(self.details_frame, fg_color="transparent")
        btn_frame.grid(row=1, column=0, sticky="ew", padx=20, pady=10)
        btn_frame.grid_columnconfigure((0, 1, 2), weight=1)
        
        save_btn = ctk.CTkButton(
            btn_frame,
            text="💾 Save Trip",
            fg_color="#00d9ff",
            text_color="#0a1628",
            command=self.save_current_trip
        )
        save_btn.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        
        export_btn = ctk.CTkButton(
            btn_frame,
            text="📄 Export PDF",
            fg_color="#00a8cc",
            text_color="#ffffff",
            command=self.export_trip
        )
        export_btn.grid(row=0, column=1, sticky="ew", padx=5)
        
        share_btn = ctk.CTkButton(
            btn_frame,
            text="📤 Share",
            fg_color="#0081b4",
            text_color="#ffffff",
            command=self.share_trip
        )
        share_btn.grid(row=0, column=2, sticky="ew", padx=(5, 0))
    
    def setup_saved_trips_tab(self):
        """Setup saved trips tab"""
        self.saved_frame.grid_rowconfigure(0, weight=1)
        self.saved_frame.grid_columnconfigure(0, weight=1)
        
        # Create listbox
        self.trips_listbox = ctk.CTkTextbox(self.saved_frame, fg_color="#1a1a1a")
        self.trips_listbox.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        
        self.refresh_saved_trips()
    
    def setup_analytics_tab(self):
        """Setup analytics tab"""
        self.analytics_frame.grid_rowconfigure(0, weight=1)
        self.analytics_frame.grid_columnconfigure(0, weight=1)
        
        scroll_frame = ctk.CTkScrollableFrame(self.analytics_frame, fg_color="transparent")
        scroll_frame.grid(row=0, column=0, sticky="nsew", padx=20, pady=20)
        scroll_frame.grid_columnconfigure(0, weight=1)
        
        # Title
        title_label = ctk.CTkLabel(
            scroll_frame,
            text="📊 Travel Analytics",
            font=("Helvetica", 24, "bold"),
            text_color="#00d9ff"
        )
        title_label.grid(row=0, column=0, sticky="w", pady=(0, 20))
        
        # Get statistics
        stats = self.trip_manager.get_statistics()
        
        # Display stats
        analytics_text = f"""
🌍 TRAVEL STATISTICS
{'='*50}

📊 Total Trips: {stats.total_trips}
📍 Total Distance: {stats.total_distance_traveled:.0f} km
💰 Total Spent: ₹{stats.total_money_spent:.0f}
⏱️ Average Trip Duration: {stats.average_trip_duration:.1f} days

🏙️ Favorite Cities: {', '.join(stats.favorite_cities) if stats.favorite_cities else 'None yet'}
✈️ Favorite Transport: {stats.favorite_transport_mode if stats.favorite_transport_mode else 'None yet'}
🌍 Most Visited: {stats.most_visited_city if stats.most_visited_city else 'None yet'}
🌱 Carbon Footprint: {stats.carbon_footprint:.0f} kg CO2

{'='*50}
        """
        
        stats_label = ctk.CTkLabel(
            scroll_frame,
            text=analytics_text,
            font=("Courier", 11),
            text_color="#888888",
            justify="left"
        )
        stats_label.grid(row=1, column=0, sticky="w", pady=10)
    
    def generate_itinerary(self):
        """Generate trip itinerary"""
        try:
            # Validate inputs
            duration = int(self.duration_var.get())
            budget = float(self.budget_var.get())
            risk = float(self.risk_var.get())
            
            if duration <= 0 or budget <= 0:
                messagebox.showerror("Error", "Duration and budget must be positive")
                return
            
            if not (0 <= risk <= 1):
                messagebox.showerror("Error", "Risk tolerance must be between 0 and 1")
                return
            
            # Create trip parameters
            trip_params = {
                "source": self.source_var.get(),
                "destination": self.dest_var.get(),
                "start_date": self.start_date_var.get(),
                "duration_days": duration,
                "budget": budget,
                "transport_preference": TransportMode(self.transport_var.get()),
                "comfort_preference": ComfortLevel(self.comfort_var.get()),
                "risk_tolerance": risk,
                "user_interests": [i.strip() for i in self.interests_var.get().split(",")]
            }
            
            # Generate itinerary
            messagebox.showinfo("Generating", "Generating your perfect itinerary...")
            self.current_trip = self.itinerary_gen.generate_itinerary(trip_params)
            
            # Generate insights
            insights = self.insights_engine.generate_insights(self.current_trip)
            self.current_trip.ai_recommendations = [i.title + ": " + i.description for i in insights]
            
            # Display trip details
            self.display_trip_details(self.current_trip)
            
            # Switch to details tab
            self.notebook.select(2)
            
            messagebox.showinfo("Success", "Itinerary generated successfully!")
            
        except ValueError as e:
            messagebox.showerror("Error", f"Invalid input: {e}")
        except Exception as e:
            messagebox.showerror("Error", f"Error generating itinerary: {e}")
    
    def display_trip_details(self, trip: TripItinerary):
        """Display trip details in details tab"""
        self.details_text.delete("1.0", "end")
        
        details = f"""
{'='*80}
✈️ TRIP ITINERARY: {trip.source} → {trip.destination}
{'='*80}

📅 TRIP OVERVIEW
{'-'*80}
Trip ID: {trip.trip_id}
Duration: {trip.duration_days} days ({trip.start_date} to {trip.end_date})
Budget: ₹{trip.budget:.0f}
Total Cost: ₹{trip.total_cost:.0f}
Distance: {trip.total_distance_km:.0f} km
Transport: {trip.transport_preference.value.upper()}
Comfort Level: {trip.comfort_preference.value.upper()}

{'='*80}
📋 DAY-BY-DAY ITINERARY
{'='*80}
"""
        
        for day in trip.days:
            details += f"""
📍 DAY {day.day_number} - {day.date} ({day.city})
{'-'*80}
Activities:
"""
            for activity in day.activities:
                details += f"  • {activity}\n"
            
            if day.hotels:
                details += f"\n🏨 Hotels:\n"
                for hotel in day.hotels:
                    details += f"  • {hotel.name} - ₹{hotel.price_per_night:.0f}/night (Rating: {hotel.rating}/5)\n"
            
            if day.attractions:
                details += f"\n🎫 Attractions:\n"
                for attr in day.attractions:
                    details += f"  • {attr.name} - {attr.description} (Rating: {attr.rating}/5)\n"
            
            if day.meals:
                details += f"\n🍽️ Meals:\n"
                for meal_type, meal in day.meals.items():
                    details += f"  • {meal_type.capitalize()}: {meal}\n"
            
            details += f"\n💰 Estimated Daily Budget: ₹{day.estimated_budget:.0f}\n"
        
        details += f"""
{'='*80}
💡 AI RECOMMENDATIONS
{'='*80}
"""
        for rec in trip.ai_recommendations[:10]:
            details += f"• {rec}\n"
        
        self.details_text.insert("end", details)
        self.details_text.configure(state="disabled")
    
    def save_current_trip(self):
        """Save current trip"""
        if not self.current_trip:
            messagebox.showerror("Error", "No trip to save")
            return
        
        if self.trip_manager.save_trip(self.current_trip):
            self.trip_manager.update_statistics(self.current_trip)
            messagebox.showinfo("Success", f"Trip saved successfully!\nTrip ID: {self.current_trip.trip_id}")
            self.refresh_saved_trips()
        else:
            messagebox.showerror("Error", "Failed to save trip")
    
    def load_trip_dialog(self):
        """Load trip dialog"""
        trips = self.trip_manager.get_all_trips()
        if not trips:
            messagebox.showinfo("Info", "No saved trips found")
            return
        
        # Create selection dialog
        trip_names = [f"{t.source} → {t.destination} ({t.start_date})" for t in trips]
        # For now, just load the first trip
        if trips:
            self.current_trip = trips[0]
            self.display_trip_details(self.current_trip)
            self.notebook.select(2)
    
    def export_trip(self):
        """Export trip to PDF"""
        if not self.current_trip:
            messagebox.showerror("Error", "No trip to export")
            return
        
        messagebox.showinfo("Export", "PDF export feature coming soon!")
    
    def share_trip(self):
        """Share trip"""
        if not self.current_trip:
            messagebox.showerror("Error", "No trip to share")
            return
        
        messagebox.showinfo("Share", "Trip sharing feature coming soon!")
    
    def refresh_saved_trips(self):
        """Refresh saved trips list"""
        self.trips_listbox.configure(state="normal")
        self.trips_listbox.delete("1.0", "end")
        
        trips = self.trip_manager.get_all_trips()
        
        if not trips:
            self.trips_listbox.insert("end", "No saved trips yet")
        else:
            content = "💾 SAVED TRIPS\n" + "="*60 + "\n\n"
            for trip in trips:
                summary = self.trip_manager.get_trip_summary(trip)
                content += f"""
📍 {summary['source']} → {summary['destination']}
   📅 {summary['start_date']} to {summary['end_date']} ({summary['duration_days']} days)
   💰 ₹{summary['total_cost']:.0f} / ₹{summary['budget']:.0f}
   ✈️ {summary['transport_mode'].upper()}
   ID: {summary['trip_id']}
{'-'*60}
"""
            self.trips_listbox.insert("end", content)
        
        self.trips_listbox.configure(state="disabled")


def main():
    """Main entry point"""
    app = SmartTripPlannerApp()
    app.mainloop()


if __name__ == "__main__":
    main()
